using AP_Project.Helpers;
using AP_Project.Models;
using AP_Project.Services;
using ClosedXML.Excel;
using LiveChartsCore;
using LiveChartsCore.Defaults;
using LiveChartsCore.SkiaSharpView;
using LiveChartsCore.SkiaSharpView.Painting;
using Microsoft.Win32;
using SkiaSharp;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;

namespace AP_Project.Views;

// ── ViewModel for chart bindings ─────────────────────────────────────
public class ReportViewModel : INotifyPropertyChanged
{
    private ISeries[] _barSeries  = [];
    private ISeries[] _pieSeries  = [];
    private Axis[]    _barXAxes   = [new Axis()];
    private Axis[]    _barYAxes   = [new Axis()];

    public ISeries[] BarSeries  { get => _barSeries;  set { _barSeries  = value; OnPC(); } }
    public ISeries[] PieSeries  { get => _pieSeries;  set { _pieSeries  = value; OnPC(); } }
    public Axis[]    BarXAxes   { get => _barXAxes;   set { _barXAxes   = value; OnPC(); } }
    public Axis[]    BarYAxes   { get => _barYAxes;   set { _barYAxes   = value; OnPC(); } }

    public event PropertyChangedEventHandler? PropertyChanged;
    void OnPC([CallerMemberName] string? n = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
}

// ── Page ─────────────────────────────────────────────────────────────
public partial class ReportsPage : Page
{
    private DataTable? _currentData;
    private readonly ReportViewModel _vm = new();

    // Colour palette for pie / bar slices
    private static readonly SKColor[] Palette =
    [
        SKColor.Parse("#0B6E1E"), SKColor.Parse("#2E7D32"), SKColor.Parse("#00897B"),
        SKColor.Parse("#43A047"), SKColor.Parse("#C62828"), SKColor.Parse("#F9A825"),
        SKColor.Parse("#1565C0"), SKColor.Parse("#EF6C00"), SKColor.Parse("#00ACC1"),
        SKColor.Parse("#8D6E63"),
    ];

    public ReportsPage()
    {
        InitializeComponent();
        DataContext = _vm;

        Loaded += (s, e) =>
        {
            var provinces = LocationService.GetProvinces();
            provinces.Insert(0, new Province { ProvinceId = 0, ProvinceName = "All Provinces" });
            cmbProvince.ItemsSource   = provinces;
            cmbProvince.SelectedIndex = 0;

            dtpFrom.SelectedDateTime = new DateTime(DateTime.Today.Year, 1, 1);
            dtpTo.SelectedDateTime   = DateTime.Today;
            GenerateReport();
        };
    }

    // ── Filter events ────────────────────────────────────────────────
    private void CmbProvince_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (!IsLoaded || cmbDistrict == null) return;
        var districts = cmbProvince.SelectedValue is int pId && pId > 0
            ? LocationService.GetDistricts(pId)
            : LocationService.GetDistricts();
        districts.Insert(0, new District { DistrictId = 0, DistrictName = "All Districts" });
        cmbDistrict.ItemsSource   = districts;
        cmbDistrict.SelectedIndex = 0;
    }

    private void CmbDistrict_Changed(object sender, SelectionChangedEventArgs e) { }
    private void ReportType_Changed(object sender, RoutedEventArgs e) { if (IsLoaded) GenerateReport(); }
    private void BtnGenerate_Click(object sender, RoutedEventArgs e) => GenerateReport();

    // ── Core generate ────────────────────────────────────────────────
    private void GenerateReport()
    {
        try
        {
            var districtId = cmbDistrict?.SelectedValue is int dv && dv != 0 ? (int?)dv : null;
            var from = dtpFrom?.SelectedDateTime;
            var to   = dtpTo?.SelectedDateTime;

            string sql, title;

            if (rbPopulation.IsChecked == true)
            {
                title = "Population Summary Report";
                sql   = BuildPopulationSql(districtId, from, to);
            }
            else if (rbGender.IsChecked == true)
            {
                title = "Gender Distribution Report";
                sql   = BuildGenderSql(districtId);
            }
            else if (rbAge.IsChecked == true)
            {
                title = "Age Group Report";
                sql   = BuildAgeSql(districtId);
            }
            else if (rbEducation.IsChecked == true)
            {
                title = "Education Level Report";
                sql   = BuildEducationSql(districtId);
            }
            else if (rbOccupation.IsChecked == true)
            {
                title = "Occupation Report";
                sql   = BuildOccupationSql(districtId);
            }
            else
            {
                title = "Household Report";
                sql   = BuildHouseholdSql(districtId, from, to);
            }

            _currentData = DatabaseHelper.ExecuteQuery(sql);

            // Table
            dgReport.ItemsSource   = _currentData.DefaultView;
            txtReportTitle.Text    = title;
            txtReportDate.Text     = $"Generated: {DateTime.Now:dd-MMM-yyyy HH:mm}";
            txtSummary.Text        = $"Total Records: {_currentData.Rows.Count}";
            kpiRecords.Text        = _currentData.Rows.Count.ToString("N0");

            // Charts
            RenderCharts(title);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error generating report: {ex.Message}", "Report Error",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    // ── Chart rendering ──────────────────────────────────────────────
    private void RenderCharts(string title)
    {
        if (_currentData == null || _currentData.Rows.Count == 0)
        {
            _vm.BarSeries = [];
            _vm.PieSeries = [];
            ClearKpi();
            return;
        }

        if (rbPopulation.IsChecked == true)   RenderPopulationCharts();
        else if (rbGender.IsChecked == true)  RenderGenderCharts();
        else if (rbAge.IsChecked == true)     RenderAgeCharts();
        else if (rbEducation.IsChecked == true) RenderEducationCharts();
        else if (rbOccupation.IsChecked == true) RenderOccupationCharts();
        else                                  RenderHouseholdCharts();
    }

    // Population: bar = households per UC, pie = male vs female
    private void RenderPopulationCharts()
    {
        var dt = _currentData!;
        var labels  = dt.Rows.Cast<DataRow>().Select(r => r["Union Council"].ToString()!).ToArray();
        var hh      = dt.Rows.Cast<DataRow>().Select(r => Convert.ToDouble(r["Households"])).ToArray();
        var males   = dt.Rows.Cast<DataRow>().Select(r => Convert.ToDouble(r["Males"])).ToArray();
        var females = dt.Rows.Cast<DataRow>().Select(r => Convert.ToDouble(r["Females"])).ToArray();
        var totPop  = (long)dt.Rows.Cast<DataRow>().Sum(r => Convert.ToDouble(r["Total Population"]));
        var totMale = (long)males.Sum();
        var totFem  = (long)females.Sum();

        txtChart1Title.Text = "Households & Population by Union Council";
        txtChart2Title.Text = "Male vs Female Split";

        _vm.BarSeries = [
            new ColumnSeries<double>
            {
                Name   = "Households",
                Values = hh,
                Fill   = new SolidColorPaint(Palette[0]),
                Stroke = null,
            },
            new ColumnSeries<double>
            {
                Name   = "Total Population",
                Values = dt.Rows.Cast<DataRow>().Select(r => Convert.ToDouble(r["Total Population"])).ToArray(),
                Fill   = new SolidColorPaint(Palette[1]),
                Stroke = null,
            }
        ];
        SetBarAxes(labels);

        _vm.PieSeries = [
            new PieSeries<double> { Name = "Male",   Values = [totMale], Fill = new SolidColorPaint(Palette[0]) },
            new PieSeries<double> { Name = "Female", Values = [totFem],  Fill = new SolidColorPaint(Palette[4]) },
        ];

        SetKpi("TOTAL POPULATION", totPop.ToString("N0"),
               "TOTAL MALES",      totMale.ToString("N0"),
               "TOTAL FEMALES",    totFem.ToString("N0"));
    }

    // Gender: bar = count per district per gender, pie = overall split
    private void RenderGenderCharts()
    {
        var dt = _currentData!;
        var districts = dt.Rows.Cast<DataRow>().Select(r => r["District"].ToString()!).Distinct().ToArray();
        var males    = districts.Select(d => dt.Rows.Cast<DataRow>()
            .Where(r => r["District"].ToString() == d && r["Gender"].ToString() == "Male")
            .Sum(r => Convert.ToDouble(r["Count"]))).ToArray();
        var females  = districts.Select(d => dt.Rows.Cast<DataRow>()
            .Where(r => r["District"].ToString() == d && r["Gender"].ToString() == "Female")
            .Sum(r => Convert.ToDouble(r["Count"]))).ToArray();
        var totM = (long)males.Sum();
        var totF = (long)females.Sum();

        txtChart1Title.Text = "Male vs Female by District";
        txtChart2Title.Text = "Overall Gender Distribution";

        _vm.BarSeries = [
            new ColumnSeries<double> { Name = "Male",   Values = males,   Fill = new SolidColorPaint(Palette[0]), Stroke = null },
            new ColumnSeries<double> { Name = "Female", Values = females, Fill = new SolidColorPaint(Palette[4]), Stroke = null },
        ];
        SetBarAxes(districts);

        _vm.PieSeries = [
            new PieSeries<double> { Name = "Male",   Values = [totM], Fill = new SolidColorPaint(Palette[0]) },
            new PieSeries<double> { Name = "Female", Values = [totF], Fill = new SolidColorPaint(Palette[4]) },
        ];

        SetKpi("TOTAL PERSONS",   (totM + totF).ToString("N0"),
               "MALES",           totM.ToString("N0"),
               "FEMALES",         totF.ToString("N0"));
    }

    // Age: bar = count per age group, pie = share
    private void RenderAgeCharts()
    {
        var dt     = _currentData!;
        var groups = dt.Rows.Cast<DataRow>().Select(r => r["Age Group"].ToString()!).ToArray();
        var counts = dt.Rows.Cast<DataRow>().Select(r => Convert.ToDouble(r["Count"])).ToArray();
        var total  = (long)counts.Sum();

        txtChart1Title.Text = "Population by Age Group";
        txtChart2Title.Text = "Age Group Distribution";

        _vm.BarSeries = [
            new ColumnSeries<double>
            {
                Name   = "Count",
                Values = counts,
                Fill   = new SolidColorPaint(Palette[2]),
                Stroke = null,
            }
        ];
        SetBarAxes(groups);

        _vm.PieSeries = groups.Select((g, i) => (ISeries)new PieSeries<double>
        {
            Name   = g,
            Values = [counts[i]],
            Fill   = new SolidColorPaint(Palette[i % Palette.Length]),
        }).ToArray();

        var biggest = dt.Rows.Cast<DataRow>().OrderByDescending(r => Convert.ToDouble(r["Count"])).First();
        SetKpi("TOTAL PERSONS",   total.ToString("N0"),
               "LARGEST GROUP",   biggest["Age Group"].ToString()!,
               "GROUP COUNT",     Convert.ToInt64(biggest["Count"]).ToString("N0"));
    }

    // Education: bar = count per level, pie = share
    private void RenderEducationCharts()
    {
        var dt     = _currentData!;
        var levels = dt.Rows.Cast<DataRow>().Select(r => r["Education Level"].ToString()!).ToArray();
        var counts = dt.Rows.Cast<DataRow>().Select(r => Convert.ToDouble(r["Count"])).ToArray();
        var total  = (long)counts.Sum();

        txtChart1Title.Text = "Education Level Distribution";
        txtChart2Title.Text = "Education Share";

        _vm.BarSeries = [
            new ColumnSeries<double> { Name = "Count", Values = counts, Fill = new SolidColorPaint(Palette[3]), Stroke = null }
        ];
        SetBarAxes(levels);

        _vm.PieSeries = levels.Select((l, i) => (ISeries)new PieSeries<double>
        {
            Name   = l,
            Values = [counts[i]],
            Fill   = new SolidColorPaint(Palette[i % Palette.Length]),
        }).ToArray();

        var literateCount = dt.Rows.Cast<DataRow>()
            .Where(r => r["Education Level"].ToString() != "None" && r["Education Level"].ToString() != "Illiterate")
            .Sum(r => Convert.ToDouble(r["Count"]));

        SetKpi("TOTAL PERSONS",   total.ToString("N0"),
               "LITERATE",        ((long)literateCount).ToString("N0"),
               "ILLITERATE",      ((long)(total - literateCount)).ToString("N0"));
    }

    // Occupation: bar = count per job, pie = share
    private void RenderOccupationCharts()
    {
        var dt   = _currentData!;
        var jobs = dt.Rows.Cast<DataRow>().Select(r => r["Occupation"].ToString()!).ToArray();
        var cnts = dt.Rows.Cast<DataRow>().Select(r => Convert.ToDouble(r["Count"])).ToArray();
        var total = (long)cnts.Sum();

        txtChart1Title.Text = "Occupation Breakdown";
        txtChart2Title.Text = "Occupation Share";

        _vm.BarSeries = [
            new ColumnSeries<double> { Name = "Count", Values = cnts, Fill = new SolidColorPaint(Palette[5]), Stroke = null }
        ];
        SetBarAxes(jobs);

        _vm.PieSeries = jobs.Take(8).Select((j, i) => (ISeries)new PieSeries<double>
        {
            Name   = j,
            Values = [cnts[i]],
            Fill   = new SolidColorPaint(Palette[i % Palette.Length]),
        }).ToArray();

        var top = dt.Rows.Cast<DataRow>().OrderByDescending(r => Convert.ToDouble(r["Count"])).First();
        SetKpi("TOTAL PERSONS",    total.ToString("N0"),
               "TOP OCCUPATION",   top["Occupation"].ToString()!,
               "TOP COUNT",        Convert.ToInt64(top["Count"]).ToString("N0"));
    }

    // Household: bar = income range buckets, pie = housing type
    private void RenderHouseholdCharts()
    {
        var dt    = _currentData!;
        var total = dt.Rows.Count;

        // Housing type pie
        var types = dt.Rows.Cast<DataRow>()
            .GroupBy(r => r["Housing"].ToString()!)
            .Select(g => (Type: g.Key, Count: g.Count()))
            .OrderByDescending(x => x.Count)
            .ToArray();

        // Status bar
        var statuses = dt.Rows.Cast<DataRow>()
            .GroupBy(r => r["Status"].ToString()!)
            .Select(g => (Status: g.Key, Count: g.Count()))
            .ToArray();

        txtChart1Title.Text = "Households by Status";
        txtChart2Title.Text = "Housing Type Distribution";

        _vm.BarSeries = [
            new ColumnSeries<double>
            {
                Name   = "Households",
                Values = statuses.Select(x => (double)x.Count).ToArray(),
                Fill   = new SolidColorPaint(Palette[0]),
                Stroke = null,
            }
        ];
        SetBarAxes(statuses.Select(x => x.Status).ToArray());

        _vm.PieSeries = types.Select((t, i) => (ISeries)new PieSeries<double>
        {
            Name   = t.Type,
            Values = [(double)t.Count],
            Fill   = new SolidColorPaint(Palette[i % Palette.Length]),
        }).ToArray();

        var avgIncome = dt.Rows.Cast<DataRow>()
            .Average(r => Convert.ToDouble(r["Income (PKR)"]));

        SetKpi("TOTAL HOUSEHOLDS",  total.ToString("N0"),
               "AVG INCOME (PKR)", avgIncome.ToString("N0"),
               "HOUSING TYPES",    types.Length.ToString());
    }

    // ── Helpers ──────────────────────────────────────────────────────
    private void SetBarAxes(string[] labels)
    {
        _vm.BarXAxes = [
            new Axis
            {
                Labels         = labels,
                LabelsRotation = labels.Length > 5 ? -35 : 0,
                TextSize       = 10,
            }
        ];
        _vm.BarYAxes = [ new Axis { TextSize = 10 } ];
    }

    private void SetKpi(string l2, string v2, string l3, string v3, string? l4 = null, string? v4 = null)
    {
        kpi2Label.Text = l2; kpi2Value.Text = v2;
        kpi3Label.Text = l3; kpi3Value.Text = v3;
        kpi4Label.Text = l4 ?? ""; kpi4Value.Text = v4 ?? "—";
    }

    private void ClearKpi()
    {
        kpi2Label.Text = ""; kpi2Value.Text = "—";
        kpi3Label.Text = ""; kpi3Value.Text = "—";
        kpi4Label.Text = ""; kpi4Value.Text = "—";
    }

    // ── SQL builders (unchanged logic) ───────────────────────────────
    private string BuildPopulationSql(int? districtId, DateTime? from, DateTime? to)
    {
        var where = new List<string>();
        if (districtId.HasValue) where.Add($"uc.DistrictId = {districtId}");
        if (from.HasValue) where.Add($"h.SurveyDate >= '{from:yyyy-MM-dd}'");
        if (to.HasValue)   where.Add($"h.SurveyDate <= '{to:yyyy-MM-dd}'");
        var w = where.Count > 0 ? "WHERE " + string.Join(" AND ", where) : "";
        return $@"SELECT d.DistrictName AS [District], uc.UnionCouncilName AS [Union Council],
                  COUNT(DISTINCT h.HouseholdId) AS [Households],
                  COUNT(p.PersonId) AS [Total Population],
                  SUM(CASE WHEN p.Gender='Male' THEN 1 ELSE 0 END) AS [Males],
                  SUM(CASE WHEN p.Gender='Female' THEN 1 ELSE 0 END) AS [Females],
                  ISNULL(AVG(CAST(p.Age AS FLOAT)),0) AS [Avg Age]
                  FROM UnionCouncils uc
                  JOIN Districts d ON uc.DistrictId = d.DistrictId
                  LEFT JOIN Households h ON uc.UnionCouncilId = h.UnionCouncilId
                  LEFT JOIN Persons p ON h.HouseholdId = p.HouseholdId
                  {w}
                  GROUP BY d.DistrictName, uc.UnionCouncilName
                  ORDER BY d.DistrictName, uc.UnionCouncilName";
    }

    private string BuildHouseholdSql(int? districtId, DateTime? from, DateTime? to)
    {
        var where = new List<string>();
        if (districtId.HasValue) where.Add($"uc.DistrictId = {districtId}");
        if (from.HasValue) where.Add($"h.SurveyDate >= '{from:yyyy-MM-dd}'");
        if (to.HasValue)   where.Add($"h.SurveyDate <= '{to:yyyy-MM-dd}'");
        var w = where.Count > 0 ? "WHERE " + string.Join(" AND ", where) : "";
        return $@"SELECT h.HouseholdCode AS [Code], h.HeadOfHousehold AS [Head],
                  uc.UnionCouncilName AS [Union Council], d.DistrictName AS [District],
                  h.HousingType AS [Housing], h.NumRooms AS [Rooms],
                  h.OwnershipStatus AS [Ownership], h.WaterSource AS [Water],
                  h.MonthlyIncome AS [Income (PKR)],
                  CASE WHEN h.HasSanitation=1 THEN 'Yes' ELSE 'No' END AS [Sanitation],
                  CASE WHEN h.HasInternet=1 THEN 'Yes' ELSE 'No' END AS [Internet],
                  h.Status AS [Status], CONVERT(varchar,h.SurveyDate,106) AS [Survey Date]
                  FROM Households h
                  JOIN UnionCouncils uc ON h.UnionCouncilId = uc.UnionCouncilId
                  JOIN Districts d ON uc.DistrictId = d.DistrictId
                  {w}
                  ORDER BY h.SurveyDate DESC";
    }

    private string BuildGenderSql(int? districtId)
    {
        var w = districtId.HasValue ? $"WHERE uc.DistrictId = {districtId}" : "";
        return $@"SELECT d.DistrictName AS [District], p.Gender AS [Gender],
                  COUNT(*) AS [Count],
                  CAST(COUNT(*)*100.0/SUM(COUNT(*)) OVER(PARTITION BY d.DistrictId) AS DECIMAL(5,1)) AS [Percentage %]
                  FROM Persons p
                  JOIN Households h ON p.HouseholdId = h.HouseholdId
                  JOIN UnionCouncils uc ON h.UnionCouncilId = uc.UnionCouncilId
                  JOIN Districts d ON uc.DistrictId = d.DistrictId
                  {w}
                  GROUP BY d.DistrictName, d.DistrictId, p.Gender
                  ORDER BY d.DistrictName, p.Gender";
    }

    private string BuildEducationSql(int? districtId)
    {
        var w = districtId.HasValue ? $"WHERE uc.DistrictId = {districtId}" : "";
        return $@"SELECT p.Education AS [Education Level], COUNT(*) AS [Count],
                  CAST(COUNT(*)*100.0/(SELECT COUNT(*) FROM Persons) AS DECIMAL(5,1)) AS [Percentage %],
                  SUM(CASE WHEN p.Gender='Male' THEN 1 ELSE 0 END) AS [Males],
                  SUM(CASE WHEN p.Gender='Female' THEN 1 ELSE 0 END) AS [Females]
                  FROM Persons p
                  JOIN Households h ON p.HouseholdId = h.HouseholdId
                  JOIN UnionCouncils uc ON h.UnionCouncilId = uc.UnionCouncilId
                  {w}
                  GROUP BY p.Education ORDER BY [Count] DESC";
    }

    private string BuildOccupationSql(int? districtId)
    {
        var w = districtId.HasValue ? $"WHERE uc.DistrictId = {districtId}" : "";
        return $@"SELECT p.Occupation AS [Occupation], COUNT(*) AS [Count],
                  CAST(COUNT(*)*100.0/(SELECT COUNT(*) FROM Persons) AS DECIMAL(5,1)) AS [Percentage %],
                  ISNULL(AVG(CAST(p.Age AS FLOAT)),0) AS [Avg Age]
                  FROM Persons p
                  JOIN Households h ON p.HouseholdId = h.HouseholdId
                  JOIN UnionCouncils uc ON h.UnionCouncilId = uc.UnionCouncilId
                  {w}
                  GROUP BY p.Occupation ORDER BY [Count] DESC";
    }

    private string BuildAgeSql(int? districtId)
    {
        var w = districtId.HasValue ? $"WHERE uc.DistrictId = {districtId}" : "";
        return $@"SELECT
                  CASE WHEN p.Age BETWEEN 0  AND 4  THEN '0-4 (Infant)'
                       WHEN p.Age BETWEEN 5  AND 14 THEN '5-14 (Child)'
                       WHEN p.Age BETWEEN 15 AND 24 THEN '15-24 (Youth)'
                       WHEN p.Age BETWEEN 25 AND 44 THEN '25-44 (Adult)'
                       WHEN p.Age BETWEEN 45 AND 64 THEN '45-64 (Middle Age)'
                       ELSE '65+ (Senior)' END AS [Age Group],
                  COUNT(*) AS [Count],
                  SUM(CASE WHEN p.Gender='Male'   THEN 1 ELSE 0 END) AS [Males],
                  SUM(CASE WHEN p.Gender='Female' THEN 1 ELSE 0 END) AS [Females]
                  FROM Persons p
                  JOIN Households h ON p.HouseholdId = h.HouseholdId
                  JOIN UnionCouncils uc ON h.UnionCouncilId = uc.UnionCouncilId
                  {w}
                  GROUP BY CASE WHEN p.Age BETWEEN 0  AND 4  THEN '0-4 (Infant)'
                       WHEN p.Age BETWEEN 5  AND 14 THEN '5-14 (Child)'
                       WHEN p.Age BETWEEN 15 AND 24 THEN '15-24 (Youth)'
                       WHEN p.Age BETWEEN 25 AND 44 THEN '25-44 (Adult)'
                       WHEN p.Age BETWEEN 45 AND 64 THEN '45-64 (Middle Age)'
                       ELSE '65+ (Senior)' END
                  ORDER BY MIN(p.Age)";
    }

    // ── Excel export ─────────────────────────────────────────────────
    private void BtnExportExcel_Click(object sender, RoutedEventArgs e)
    {
        if (_currentData == null || _currentData.Rows.Count == 0)
        { MessageBox.Show("No data to export.", "Export", MessageBoxButton.OK, MessageBoxImage.Information); return; }

        var dlg = new SaveFileDialog { Filter = "Excel Files|*.xlsx", FileName = $"CensusReport_{DateTime.Now:yyyyMMdd_HHmm}.xlsx" };
        if (dlg.ShowDialog() != true) return;

        try
        {
            using var wb = new XLWorkbook();
            var ws = wb.Worksheets.Add("Census Report");
            ws.Cell(1,1).Value = txtReportTitle.Text; ws.Cell(1,1).Style.Font.Bold = true; ws.Cell(1,1).Style.Font.FontSize = 14;
            ws.Cell(2,1).Value = $"Generated: {DateTime.Now:dd-MMM-yyyy HH:mm}";
            ws.Cell(3,1).Value = $"Total Records: {_currentData.Rows.Count}";
            for (int c = 0; c < _currentData.Columns.Count; c++)
            {
                ws.Cell(5, c+1).Value = _currentData.Columns[c].ColumnName;
                ws.Cell(5, c+1).Style.Font.Bold = true;
                ws.Cell(5, c+1).Style.Fill.BackgroundColor = XLColor.FromHtml("#0B6E1E");
                ws.Cell(5, c+1).Style.Font.FontColor = XLColor.White;
            }
            for (int r = 0; r < _currentData.Rows.Count; r++)
            {
                for (int c = 0; c < _currentData.Columns.Count; c++)
                    ws.Cell(r+6, c+1).Value = _currentData.Rows[r][c]?.ToString();
                if (r % 2 == 1) ws.Row(r+6).Style.Fill.BackgroundColor = XLColor.FromHtml("#F0F5F0");
            }
            ws.Columns().AdjustToContents();
            wb.SaveAs(dlg.FileName);
            MessageBox.Show("Excel exported successfully!", "Export", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex) { MessageBox.Show($"Export failed: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    // ── PDF export ───────────────────────────────────────────────────
    private void BtnExportPdf_Click(object sender, RoutedEventArgs e)
    {
        if (_currentData == null || _currentData.Rows.Count == 0)
        { MessageBox.Show("No data to export.", "Export", MessageBoxButton.OK, MessageBoxImage.Information); return; }

        var dlg = new SaveFileDialog { Filter = "PDF Files|*.pdf", FileName = $"CensusReport_{DateTime.Now:yyyyMMdd_HHmm}.pdf" };
        if (dlg.ShowDialog() != true) return;

        try
        {
            using var writer = new iText.Kernel.Pdf.PdfWriter(dlg.FileName);
            using var pdf    = new iText.Kernel.Pdf.PdfDocument(writer);
            using var doc    = new iText.Layout.Document(pdf, iText.Kernel.Geom.PageSize.A4.Rotate());

            var tf = iText.Kernel.Font.PdfFontFactory.CreateFont(iText.IO.Font.Constants.StandardFonts.HELVETICA_BOLD);
            var bf = iText.Kernel.Font.PdfFontFactory.CreateFont(iText.IO.Font.Constants.StandardFonts.HELVETICA);

            doc.Add(new iText.Layout.Element.Paragraph(txtReportTitle.Text).SetFont(tf).SetFontSize(16).SetMarginBottom(5));
            doc.Add(new iText.Layout.Element.Paragraph($"Generated: {DateTime.Now:dd-MMM-yyyy HH:mm}").SetFont(bf).SetFontSize(10).SetMarginBottom(15));

            var table = new iText.Layout.Element.Table(_currentData.Columns.Count).UseAllAvailableWidth();
            foreach (DataColumn col in _currentData.Columns)
                table.AddHeaderCell(new iText.Layout.Element.Cell()
                    .Add(new iText.Layout.Element.Paragraph(col.ColumnName).SetFont(tf).SetFontSize(9))
                    .SetBackgroundColor(new iText.Kernel.Colors.DeviceRgb(11,110,30))
                    .SetFontColor(iText.Kernel.Colors.ColorConstants.WHITE));

            bool alt = false;
            foreach (DataRow row in _currentData.Rows)
            {
                foreach (var item in row.ItemArray)
                {
                    var cell = new iText.Layout.Element.Cell()
                        .Add(new iText.Layout.Element.Paragraph(item?.ToString() ?? "").SetFont(bf).SetFontSize(8));
                    if (alt) cell.SetBackgroundColor(new iText.Kernel.Colors.DeviceRgb(240,245,240));
                    table.AddCell(cell);
                }
                alt = !alt;
            }
            doc.Add(table);
            MessageBox.Show("PDF exported successfully!", "Export", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex) { MessageBox.Show($"PDF export failed: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error); }
    }
}
