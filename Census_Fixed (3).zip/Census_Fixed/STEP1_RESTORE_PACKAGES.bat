@echo off
title Step 1 - Restore NuGet Packages
color 0B
echo.
echo  ================================================
echo   STEP 1: Restore NuGet Packages
echo  ================================================
echo.
echo  Checking for .NET 8 SDK...
dotnet --version >nul 2>&1
if errorlevel 1 (
    echo  ERROR: .NET 8 SDK not found!
    echo  Please install from: https://dotnet.microsoft.com/download/dotnet/8.0
    start https://dotnet.microsoft.com/download/dotnet/8.0
    pause & exit /b 1
)
echo  .NET SDK version:
dotnet --version
echo.

echo  Restoring packages (needs internet - ~1-2 minutes first time)...
cd /d "%~dp0AP_Project"
dotnet restore AP_Project.csproj --verbosity minimal
if errorlevel 1 (
    echo.
    echo  FAILED! Check internet connection and try again.
    echo  Or open CensusManagementSystem.sln in Visual Studio
    echo  and go to: Tools ^> NuGet Package Manager ^> Restore
    pause & exit /b 1
)
echo.
echo  Packages restored successfully!
echo.
echo  Now run STEP2_BUILD_AND_RUN.bat
pause
