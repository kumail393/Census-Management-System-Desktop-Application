@echo off
title Step 2 - Build and Run Census System
color 0A
echo.
echo  ================================================
echo   STEP 2: Build and Run
echo  ================================================
echo.
cd /d "%~dp0AP_Project"
echo  Building...
dotnet build AP_Project.csproj -c Debug --no-restore
if errorlevel 1 (
    echo.
    echo  Build failed! Run STEP1_RESTORE_PACKAGES.bat first.
    pause & exit /b 1
)
echo.
echo  ================================================
echo   BUILD SUCCESS - Launching Application...
echo  ================================================
echo.
echo  IMPORTANT: Before logging in, make sure you:
echo  1. Ran Database\CensusDB_CreateScript.sql in SSMS
echo  2. Updated the connection string in:
echo     Views\LoginWindow.xaml.cs  (line 13)
echo.
echo  Login: admin / admin123
echo.
start "" "bin\Debug\net8.0-windows\AP_Project.exe"
pause
