using System.Windows;
namespace AP_Project
{
    public partial class App : Application { }
}
