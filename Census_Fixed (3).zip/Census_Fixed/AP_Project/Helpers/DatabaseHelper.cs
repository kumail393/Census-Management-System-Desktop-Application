using Microsoft.Data.SqlClient;
using System.Data;

namespace AP_Project.Helpers
{
    public static class DatabaseHelper
    {
        private static string _connectionString = string.Empty;
        public static void Initialize(string cs) => _connectionString = cs;
        public static string ConnectionString => _connectionString;

        public static SqlConnection GetConnection() => new SqlConnection(_connectionString);

        public static DataTable ExecuteQuery(string query, params SqlParameter[] parameters)
        {
            var dt = new DataTable();
            using var conn = GetConnection();
            using var cmd = new SqlCommand(query, conn);
            if (parameters != null) cmd.Parameters.AddRange(parameters);
            using var adapter = new SqlDataAdapter(cmd);
            conn.Open();
            adapter.Fill(dt);
            return dt;
        }

        public static int ExecuteNonQuery(string query, params SqlParameter[] parameters)
        {
            using var conn = GetConnection();
            using var cmd = new SqlCommand(query, conn);
            if (parameters != null) cmd.Parameters.AddRange(parameters);
            conn.Open();
            return cmd.ExecuteNonQuery();
        }

        public static object? ExecuteScalar(string query, params SqlParameter[] parameters)
        {
            using var conn = GetConnection();
            using var cmd = new SqlCommand(query, conn);
            if (parameters != null) cmd.Parameters.AddRange(parameters);
            conn.Open();
            return cmd.ExecuteScalar();
        }

        public static bool TestConnection(string cs)
        {
            try { using var c = new SqlConnection(cs); c.Open(); return true; }
            catch { return false; }
        }
    }
}
