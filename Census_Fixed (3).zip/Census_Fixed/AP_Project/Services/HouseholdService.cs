using AP_Project.Helpers;
using AP_Project.Models;
using Microsoft.Data.SqlClient;

namespace AP_Project.Services
{
    public static class HouseholdService
    {
        public static List<Household> GetAll(string? search = null, string? status = null)
        {
            var where = new List<string>();
            var parms = new List<SqlParameter>();
            if (!string.IsNullOrWhiteSpace(search))
            {
                where.Add("(h.HouseholdCode LIKE @S OR h.HeadOfHousehold LIKE @S OR h.Address LIKE @S)");
                parms.Add(new SqlParameter("@S", $"%{search}%"));
            }
            if (!string.IsNullOrWhiteSpace(status)) { where.Add("h.Status=@St"); parms.Add(new SqlParameter("@St", status)); }
            var w = where.Count > 0 ? "WHERE " + string.Join(" AND ", where) : "";
            var sql = $@"SELECT h.*,uc.UnionCouncilName,u.FullName AS EnumeratorName,COUNT(p.PersonId) AS MemberCount
                FROM Households h LEFT JOIN UnionCouncils uc ON h.UnionCouncilId=uc.UnionCouncilId
                LEFT JOIN Users u ON h.EnumeratorId=u.UserId LEFT JOIN Persons p ON h.HouseholdId=p.HouseholdId
                {w} GROUP BY h.HouseholdId,h.HouseholdCode,h.UnionCouncilId,h.Address,h.HeadOfHousehold,
                h.ContactNumber,h.HousingType,h.NumRooms,h.OwnershipStatus,h.WaterSource,h.ElectricitySource,
                h.HasSanitation,h.HasInternet,h.MonthlyIncome,h.EnumeratorId,h.SurveyDate,h.Status,
                h.CreatedAt,h.UpdatedAt,uc.UnionCouncilName,u.FullName ORDER BY h.HouseholdId DESC";
            var dt = DatabaseHelper.ExecuteQuery(sql, parms.ToArray());
            var list = new List<Household>();
            foreach (System.Data.DataRow r in dt.Rows) list.Add(Map(r));
            return list;
        }

        public static Household? GetById(int id)
        {
            var dt = DatabaseHelper.ExecuteQuery(@"SELECT h.*,uc.UnionCouncilName,u.FullName AS EnumeratorName,COUNT(p.PersonId) AS MemberCount
                FROM Households h LEFT JOIN UnionCouncils uc ON h.UnionCouncilId=uc.UnionCouncilId
                LEFT JOIN Users u ON h.EnumeratorId=u.UserId LEFT JOIN Persons p ON h.HouseholdId=p.HouseholdId
                WHERE h.HouseholdId=@Id GROUP BY h.HouseholdId,h.HouseholdCode,h.UnionCouncilId,h.Address,h.HeadOfHousehold,
                h.ContactNumber,h.HousingType,h.NumRooms,h.OwnershipStatus,h.WaterSource,h.ElectricitySource,
                h.HasSanitation,h.HasInternet,h.MonthlyIncome,h.EnumeratorId,h.SurveyDate,h.Status,h.CreatedAt,h.UpdatedAt,uc.UnionCouncilName,u.FullName",
                new SqlParameter("@Id", id));
            return dt.Rows.Count > 0 ? Map(dt.Rows[0]) : null;
        }

        public static int Add(Household h)
        {
            return (int)DatabaseHelper.ExecuteScalar(@"INSERT INTO Households(HouseholdCode,UnionCouncilId,Address,HeadOfHousehold,ContactNumber,HousingType,NumRooms,OwnershipStatus,WaterSource,ElectricitySource,HasSanitation,HasInternet,MonthlyIncome,EnumeratorId,SurveyDate,Status)
                OUTPUT INSERTED.HouseholdId VALUES(@Co,@UC,@Ad,@He,@Cn,@Ho,@Ro,@Ow,@Wa,@El,@Sa,@In,@Mi,@En,@Sd,@St)",
                new SqlParameter("@Co",h.HouseholdCode), new SqlParameter("@UC",h.UnionCouncilId),
                new SqlParameter("@Ad",h.Address), new SqlParameter("@He",h.HeadOfHousehold),
                new SqlParameter("@Cn",h.ContactNumber), new SqlParameter("@Ho",h.HousingType),
                new SqlParameter("@Ro",h.NumRooms), new SqlParameter("@Ow",h.OwnershipStatus),
                new SqlParameter("@Wa",h.WaterSource), new SqlParameter("@El",h.ElectricitySource),
                new SqlParameter("@Sa",h.HasSanitation), new SqlParameter("@In",h.HasInternet),
                new SqlParameter("@Mi",h.MonthlyIncome), new SqlParameter("@En", h.EnumeratorId == 0 ? (object)System.DBNull.Value : h.EnumeratorId),
                new SqlParameter("@Sd",h.SurveyDate), new SqlParameter("@St",h.Status))!;
        }

        public static void Update(Household h) =>
            DatabaseHelper.ExecuteNonQuery(@"UPDATE Households SET HouseholdCode=@Co,UnionCouncilId=@UC,Address=@Ad,HeadOfHousehold=@He,
                ContactNumber=@Cn,HousingType=@Ho,NumRooms=@Ro,OwnershipStatus=@Ow,WaterSource=@Wa,
                ElectricitySource=@El,HasSanitation=@Sa,HasInternet=@In,MonthlyIncome=@Mi,
                EnumeratorId=@En,SurveyDate=@Sd,Status=@St WHERE HouseholdId=@Id",
                new SqlParameter("@Id",h.HouseholdId), new SqlParameter("@Co",h.HouseholdCode),
                new SqlParameter("@UC",h.UnionCouncilId), new SqlParameter("@Ad",h.Address),
                new SqlParameter("@He",h.HeadOfHousehold), new SqlParameter("@Cn",h.ContactNumber),
                new SqlParameter("@Ho",h.HousingType), new SqlParameter("@Ro",h.NumRooms),
                new SqlParameter("@Ow",h.OwnershipStatus), new SqlParameter("@Wa",h.WaterSource),
                new SqlParameter("@El",h.ElectricitySource), new SqlParameter("@Sa",h.HasSanitation),
                new SqlParameter("@In",h.HasInternet), new SqlParameter("@Mi",h.MonthlyIncome),
                new SqlParameter("@En", h.EnumeratorId == 0 ? (object)System.DBNull.Value : h.EnumeratorId), new SqlParameter("@Sd",h.SurveyDate),
                new SqlParameter("@St",h.Status));

        public static void Delete(int id)
        {
            DatabaseHelper.ExecuteNonQuery("DELETE FROM Persons WHERE HouseholdId=@Id", new SqlParameter("@Id",id));
            DatabaseHelper.ExecuteNonQuery("DELETE FROM Households WHERE HouseholdId=@Id", new SqlParameter("@Id",id));
        }

        public static string GenerateCode(int ucId)
        {
            var count = Convert.ToInt32(DatabaseHelper.ExecuteScalar("SELECT COUNT(*) FROM Households WHERE UnionCouncilId=@Id", new SqlParameter("@Id",ucId)));
            return $"HH-{ucId:D4}-{(count+1):D6}";
        }

        private static Household Map(System.Data.DataRow r) => new()
        {
            HouseholdId=(int)r["HouseholdId"], HouseholdCode=r["HouseholdCode"].ToString()!,
            UnionCouncilId=(int)r["UnionCouncilId"], UCName=r["UnionCouncilName"]?.ToString()??"",
            Address=r["Address"].ToString()!, HeadOfHousehold=r["HeadOfHousehold"].ToString()!,
            ContactNumber=r["ContactNumber"].ToString()!, HousingType=r["HousingType"].ToString()!,
            NumRooms=(int)r["NumRooms"], OwnershipStatus=r["OwnershipStatus"].ToString()!,
            WaterSource=r["WaterSource"].ToString()!, ElectricitySource=r["ElectricitySource"].ToString()!,
            HasSanitation=(bool)r["HasSanitation"], HasInternet=(bool)r["HasInternet"],
            MonthlyIncome=(decimal)r["MonthlyIncome"],
            EnumeratorId=r["EnumeratorId"]==DBNull.Value?0:(int)r["EnumeratorId"],
            EnumeratorName=r["EnumeratorName"]?.ToString()??"",
            SurveyDate=(DateTime)r["SurveyDate"], Status=r["Status"].ToString()!,
            MemberCount=r["MemberCount"]==DBNull.Value?0:Convert.ToInt32(r["MemberCount"])
        };
    }
}
