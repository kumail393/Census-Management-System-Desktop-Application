using AP_Project.Helpers;
using AP_Project.Models;
using Microsoft.Data.SqlClient;

namespace AP_Project.Services
{
    public static class PersonService
    {
        public static List<Person> GetByHousehold(int householdId)
        {
            var dt = DatabaseHelper.ExecuteQuery("SELECT p.*,h.HouseholdCode FROM Persons p LEFT JOIN Households h ON p.HouseholdId=h.HouseholdId WHERE p.HouseholdId=@Id ORDER BY p.PersonId", new SqlParameter("@Id",householdId));
            return Map(dt);
        }

        public static List<Person> GetAll(string? search=null, string? gender=null, int? districtId=null)
        {
            var where = new List<string>(); var parms = new List<SqlParameter>();
            if (!string.IsNullOrWhiteSpace(search)) { where.Add("(p.FirstName LIKE @S OR p.LastName LIKE @S OR p.CNICNumber LIKE @S)"); parms.Add(new SqlParameter("@S",$"%{search}%")); }
            if (!string.IsNullOrWhiteSpace(gender)) { where.Add("p.Gender=@G"); parms.Add(new SqlParameter("@G",gender)); }
            if (districtId.HasValue) { where.Add("uc.DistrictId=@D"); parms.Add(new SqlParameter("@D",districtId.Value)); }
            var w = where.Count>0?"WHERE "+string.Join(" AND ",where):"";
            var dt = DatabaseHelper.ExecuteQuery($"SELECT p.*,h.HouseholdCode FROM Persons p INNER JOIN Households h ON p.HouseholdId=h.HouseholdId INNER JOIN UnionCouncils uc ON h.UnionCouncilId=uc.UnionCouncilId {w} ORDER BY p.PersonId DESC", parms.ToArray());
            return Map(dt);
        }

        public static Person? GetById(int id)
        {
            var dt = DatabaseHelper.ExecuteQuery("SELECT p.*,h.HouseholdCode FROM Persons p LEFT JOIN Households h ON p.HouseholdId=h.HouseholdId WHERE p.PersonId=@Id", new SqlParameter("@Id",id));
            return dt.Rows.Count>0?MapRow(dt.Rows[0]):null;
        }

        public static int Add(Person p)
        {
            int age = CalculateAge(p.DateOfBirth);
            return (int)DatabaseHelper.ExecuteScalar(@"INSERT INTO Persons(HouseholdId,FirstName,LastName,CNICNumber,Gender,DateOfBirth,Age,MaritalStatus,Relationship,Education,Occupation,Disability,Nationality,Religion,MotherTongue)
                OUTPUT INSERTED.PersonId VALUES(@HH,@Fn,@Ln,@Cn,@Ge,@Db,@Ag,@Ms,@Re,@Ed,@Oc,@Di,@Na,@Ri,@Mt)",
                new SqlParameter("@HH",p.HouseholdId), new SqlParameter("@Fn",p.FirstName), new SqlParameter("@Ln",p.LastName),
                new SqlParameter("@Cn",p.CNICNumber), new SqlParameter("@Ge",p.Gender), new SqlParameter("@Db",p.DateOfBirth),
                new SqlParameter("@Ag",age), new SqlParameter("@Ms",p.MaritalStatus), new SqlParameter("@Re",p.Relationship),
                new SqlParameter("@Ed",p.Education), new SqlParameter("@Oc",p.Occupation),
                new SqlParameter("@Di",string.IsNullOrEmpty(p.Disability)?"None":p.Disability),
                new SqlParameter("@Na",p.Nationality), new SqlParameter("@Ri",p.Religion), new SqlParameter("@Mt",p.MotherTongue))!;
        }

        public static void Update(Person p)
        {
            int age = CalculateAge(p.DateOfBirth);
            DatabaseHelper.ExecuteNonQuery(@"UPDATE Persons SET FirstName=@Fn,LastName=@Ln,CNICNumber=@Cn,Gender=@Ge,DateOfBirth=@Db,Age=@Ag,MaritalStatus=@Ms,Relationship=@Re,Education=@Ed,Occupation=@Oc,Disability=@Di,Nationality=@Na,Religion=@Ri,MotherTongue=@Mt WHERE PersonId=@Id",
                new SqlParameter("@Id",p.PersonId), new SqlParameter("@Fn",p.FirstName), new SqlParameter("@Ln",p.LastName),
                new SqlParameter("@Cn",p.CNICNumber), new SqlParameter("@Ge",p.Gender), new SqlParameter("@Db",p.DateOfBirth),
                new SqlParameter("@Ag",age), new SqlParameter("@Ms",p.MaritalStatus), new SqlParameter("@Re",p.Relationship),
                new SqlParameter("@Ed",p.Education), new SqlParameter("@Oc",p.Occupation),
                new SqlParameter("@Di",string.IsNullOrEmpty(p.Disability)?"None":p.Disability),
                new SqlParameter("@Na",p.Nationality), new SqlParameter("@Ri",p.Religion), new SqlParameter("@Mt",p.MotherTongue));
        }

        public static void Delete(int id) => DatabaseHelper.ExecuteNonQuery("DELETE FROM Persons WHERE PersonId=@Id", new SqlParameter("@Id",id));

        public static int CalculateAge(DateTime dob) { var t=DateTime.Today; var a=t.Year-dob.Year; if(dob.Date>t.AddYears(-a))a--; return a; }

        private static List<Person> Map(System.Data.DataTable dt) { var l=new List<Person>(); foreach(System.Data.DataRow r in dt.Rows) l.Add(MapRow(r)); return l; }

        private static Person MapRow(System.Data.DataRow r) => new()
        {
            PersonId=(int)r["PersonId"], HouseholdId=(int)r["HouseholdId"], HouseholdCode=r["HouseholdCode"]?.ToString()??"",
            FirstName=r["FirstName"].ToString()!, LastName=r["LastName"].ToString()!, CNICNumber=r["CNICNumber"].ToString()!,
            Gender=r["Gender"].ToString()!, DateOfBirth=(DateTime)r["DateOfBirth"], Age=(int)r["Age"],
            MaritalStatus=r["MaritalStatus"].ToString()!, Relationship=r["Relationship"].ToString()!,
            Education=r["Education"].ToString()!, Occupation=r["Occupation"].ToString()!,
            Disability=r["Disability"].ToString()!, Nationality=r["Nationality"].ToString()!,
            Religion=r["Religion"].ToString()!, MotherTongue=r["MotherTongue"].ToString()!
        };
    }
}
