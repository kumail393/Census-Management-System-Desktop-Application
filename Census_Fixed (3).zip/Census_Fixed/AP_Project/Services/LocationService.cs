using AP_Project.Helpers;
using AP_Project.Models;
using Microsoft.Data.SqlClient;

namespace AP_Project.Services
{
    public static class LocationService
    {
        public static List<Province> GetProvinces()
        {
            var dt = DatabaseHelper.ExecuteQuery("SELECT * FROM Provinces ORDER BY ProvinceName");
            var list = new List<Province>();
            foreach (System.Data.DataRow r in dt.Rows)
                list.Add(new Province { ProvinceId=(int)r["ProvinceId"], ProvinceName=r["ProvinceName"].ToString()!, ProvinceCode=r["ProvinceCode"].ToString()! });
            return list;
        }

        public static List<District> GetDistricts(int? provinceId = null)
        {
            var sql = provinceId.HasValue
                ? "SELECT d.*,p.ProvinceName FROM Districts d JOIN Provinces p ON d.ProvinceId=p.ProvinceId WHERE d.ProvinceId=@PId ORDER BY d.DistrictName"
                : "SELECT d.*,p.ProvinceName FROM Districts d JOIN Provinces p ON d.ProvinceId=p.ProvinceId ORDER BY d.DistrictName";
            var parms = provinceId.HasValue ? new[] { new SqlParameter("@PId", provinceId.Value) } : Array.Empty<SqlParameter>();
            var dt = DatabaseHelper.ExecuteQuery(sql, parms);
            var list = new List<District>();
            foreach (System.Data.DataRow r in dt.Rows)
                list.Add(new District { DistrictId=(int)r["DistrictId"], ProvinceId=(int)r["ProvinceId"], DistrictName=r["DistrictName"].ToString()!, DistrictCode=r["DistrictCode"].ToString()!, ProvinceName=r["ProvinceName"].ToString()! });
            return list;
        }

        public static List<UnionCouncil> GetUnionCouncils(int? districtId = null)
        {
            var sql = districtId.HasValue
                ? "SELECT uc.*,d.DistrictName FROM UnionCouncils uc JOIN Districts d ON uc.DistrictId=d.DistrictId WHERE uc.DistrictId=@DId ORDER BY uc.UnionCouncilName"
                : "SELECT uc.*,d.DistrictName FROM UnionCouncils uc JOIN Districts d ON uc.DistrictId=d.DistrictId ORDER BY uc.UnionCouncilName";
            var parms = districtId.HasValue ? new[] { new SqlParameter("@DId", districtId.Value) } : Array.Empty<SqlParameter>();
            var dt = DatabaseHelper.ExecuteQuery(sql, parms);
            var list = new List<UnionCouncil>();
            foreach (System.Data.DataRow r in dt.Rows)
                list.Add(new UnionCouncil { UnionCouncilId=(int)r["UnionCouncilId"], DistrictId=(int)r["DistrictId"], UnionCouncilName=r["UnionCouncilName"].ToString()!, UCCode=r["UCCode"].ToString()!, UCType=r["UCType"].ToString()!, DistrictName=r["DistrictName"].ToString()! });
            return list;
        }

        public static void AddProvince(Province p) =>
            DatabaseHelper.ExecuteNonQuery("INSERT INTO Provinces(ProvinceName,ProvinceCode) VALUES(@N,@C)",
                new SqlParameter("@N",p.ProvinceName), new SqlParameter("@C",p.ProvinceCode));

        public static void AddDistrict(District d) =>
            DatabaseHelper.ExecuteNonQuery("INSERT INTO Districts(ProvinceId,DistrictName,DistrictCode) VALUES(@PId,@N,@C)",
                new SqlParameter("@PId",d.ProvinceId), new SqlParameter("@N",d.DistrictName), new SqlParameter("@C",d.DistrictCode));

        public static void AddUnionCouncil(UnionCouncil uc) =>
            DatabaseHelper.ExecuteNonQuery("INSERT INTO UnionCouncils(DistrictId,UnionCouncilName,UCCode,UCType) VALUES(@DId,@N,@C,@T)",
                new SqlParameter("@DId",uc.DistrictId), new SqlParameter("@N",uc.UnionCouncilName), new SqlParameter("@C",uc.UCCode), new SqlParameter("@T",uc.UCType));
    }

    public static class DashboardService
    {
        public static DashboardStats GetStats()
        {
            var stats = new DashboardStats();
            var dt = DatabaseHelper.ExecuteQuery(@"
                SELECT (SELECT COUNT(*) FROM Households) AS TotalHouseholds,
                       (SELECT COUNT(*) FROM Persons) AS TotalPersons,
                       (SELECT COUNT(*) FROM Persons WHERE Gender='Male') AS TotalMales,
                       (SELECT COUNT(*) FROM Persons WHERE Gender='Female') AS TotalFemales,
                       (SELECT COUNT(*) FROM Districts) AS TotalDistricts,
                       (SELECT COUNT(*) FROM UnionCouncils) AS TotalUCs,
                       (SELECT COUNT(*) FROM Households WHERE MONTH(SurveyDate)=MONTH(GETDATE()) AND YEAR(SurveyDate)=YEAR(GETDATE())) AS SurveysThisMonth,
                       (SELECT COUNT(*) FROM Households WHERE Status='Pending') AS PendingSurveys");
            if (dt.Rows.Count > 0)
            {
                var r = dt.Rows[0];
                stats.TotalHouseholds = (int)r["TotalHouseholds"];
                stats.TotalPersons = (int)r["TotalPersons"];
                stats.TotalMales = (int)r["TotalMales"];
                stats.TotalFemales = (int)r["TotalFemales"];
                stats.TotalDistricts = (int)r["TotalDistricts"];
                stats.TotalUCs = (int)r["TotalUCs"];
                stats.SurveysThisMonth = (int)r["SurveysThisMonth"];
                stats.PendingSurveys = (int)r["PendingSurveys"];
            }
            var lr = DatabaseHelper.ExecuteScalar("SELECT COUNT(CASE WHEN Education NOT IN('None','Illiterate') THEN 1 END)*100.0/NULLIF(COUNT(*),0) FROM Persons WHERE Age>=15");
            stats.LiteracyRate = lr == null || lr == DBNull.Value ? 0 : Math.Round(Convert.ToDouble(lr), 1);
            return stats;
        }

        public static System.Data.DataTable GetRecentActivity() =>
            DatabaseHelper.ExecuteQuery(@"SELECT TOP 10 h.HouseholdCode,h.HeadOfHousehold,uc.UnionCouncilName,h.SurveyDate,h.Status,u.FullName AS Enumerator
                FROM Households h LEFT JOIN UnionCouncils uc ON h.UnionCouncilId=uc.UnionCouncilId
                LEFT JOIN Users u ON h.EnumeratorId=u.UserId ORDER BY h.HouseholdId DESC");
    }
}
