using AP_Project.Helpers;
using AP_Project.Models;
using Microsoft.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

namespace AP_Project.Services
{
    public static class AuthService
    {
        private static User? _currentUser;
        public static User? CurrentUser => _currentUser;

        public static string HashPassword(string password)
        {
            var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(password + "CensusSalt2024"));
            return Convert.ToHexString(bytes);
        }

        public static bool Login(string username, string password)
        {
            var hash = HashPassword(password);
            var dt = DatabaseHelper.ExecuteQuery(
                "SELECT UserId,Username,FullName,Email,Role,IsActive FROM Users WHERE Username=@U AND PasswordHash=@H AND IsActive=1",
                new SqlParameter("@U", username), new SqlParameter("@H", hash));
            if (dt.Rows.Count == 0) return false;
            var row = dt.Rows[0];
            _currentUser = new User
            {
                UserId = (int)row["UserId"], Username = row["Username"].ToString()!,
                FullName = row["FullName"].ToString()!, Email = row["Email"].ToString()!,
                Role = row["Role"].ToString()!, IsActive = (bool)row["IsActive"]
            };
            DatabaseHelper.ExecuteNonQuery("UPDATE Users SET LastLogin=GETDATE() WHERE UserId=@Id",
                new SqlParameter("@Id", _currentUser.UserId));
            return true;
        }

        public static void Logout() => _currentUser = null;
    }
}
