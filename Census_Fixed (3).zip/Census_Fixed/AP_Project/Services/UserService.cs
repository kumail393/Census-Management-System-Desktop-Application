using AP_Project.Helpers;
using AP_Project.Models;
using Microsoft.Data.SqlClient;

namespace AP_Project.Services
{
    public static class UserService
    {
        public static List<User> GetAll()
        {
            var dt = DatabaseHelper.ExecuteQuery("SELECT * FROM Users ORDER BY FullName");
            var list = new List<User>();
            foreach (System.Data.DataRow r in dt.Rows) list.Add(Map(r));
            return list;
        }

        public static List<User> GetEnumerators()
        {
            var dt = DatabaseHelper.ExecuteQuery("SELECT * FROM Users WHERE Role='Enumerator' AND IsActive=1 ORDER BY FullName");
            var list = new List<User>();
            foreach (System.Data.DataRow r in dt.Rows) list.Add(Map(r));
            return list;
        }

        public static bool UsernameExists(string username, int excludeId = 0)
            => Convert.ToInt32(DatabaseHelper.ExecuteScalar("SELECT COUNT(*) FROM Users WHERE Username=@U AND UserId!=@Id",
                new SqlParameter("@U",username), new SqlParameter("@Id",excludeId))) > 0;

        public static void Add(User u, string password) =>
            DatabaseHelper.ExecuteNonQuery("INSERT INTO Users(Username,PasswordHash,FullName,Email,Role,IsActive,CreatedAt) VALUES(@U,@H,@F,@E,@R,@A,GETDATE())",
                new SqlParameter("@U",u.Username), new SqlParameter("@H",AuthService.HashPassword(password)),
                new SqlParameter("@F",u.FullName), new SqlParameter("@E",u.Email),
                new SqlParameter("@R",u.Role), new SqlParameter("@A",u.IsActive));

        public static void Update(User u) =>
            DatabaseHelper.ExecuteNonQuery("UPDATE Users SET FullName=@F,Email=@E,Role=@R,IsActive=@A WHERE UserId=@Id",
                new SqlParameter("@Id",u.UserId), new SqlParameter("@F",u.FullName),
                new SqlParameter("@E",u.Email), new SqlParameter("@R",u.Role), new SqlParameter("@A",u.IsActive));

        public static void ChangePassword(int userId, string newPassword) =>
            DatabaseHelper.ExecuteNonQuery("UPDATE Users SET PasswordHash=@H WHERE UserId=@Id",
                new SqlParameter("@H",AuthService.HashPassword(newPassword)), new SqlParameter("@Id",userId));

        public static void Delete(int id) =>
            DatabaseHelper.ExecuteNonQuery("DELETE FROM Users WHERE UserId=@Id", new SqlParameter("@Id",id));

        private static User Map(System.Data.DataRow r) => new()
        {
            UserId=(int)r["UserId"], Username=r["Username"].ToString()!, FullName=r["FullName"].ToString()!,
            Email=r["Email"].ToString()!, Role=r["Role"].ToString()!, IsActive=(bool)r["IsActive"],
            CreatedAt=(DateTime)r["CreatedAt"], LastLogin=r["LastLogin"]==DBNull.Value?null:(DateTime?)r["LastLogin"]
        };
    }
}
