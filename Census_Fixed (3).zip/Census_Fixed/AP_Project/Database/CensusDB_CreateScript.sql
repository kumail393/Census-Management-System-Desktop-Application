-- ═══════════════════════════════════════════════════════════════════════
--  CENSUS MANAGEMENT SYSTEM — Complete Database Script
--  Database: CensusDB
--  SQL Server 2016+ / SQL Server 2019 / SQL Server 2022
-- ═══════════════════════════════════════════════════════════════════════

USE master;
GO

-- Drop and recreate database
IF EXISTS (SELECT name FROM sys.databases WHERE name = 'CensusDB')
BEGIN
    ALTER DATABASE CensusDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE CensusDB;
END
GO

CREATE DATABASE CensusDB
    COLLATE SQL_Latin1_General_CP1_CI_AS;
GO

USE CensusDB;
GO

-- ═══════════════════════════════════════════════════════════════════════
-- TABLE: Users
-- ═══════════════════════════════════════════════════════════════════════
CREATE TABLE Users (
    UserId          INT             NOT NULL IDENTITY(1,1),
    Username        NVARCHAR(50)    NOT NULL,
    PasswordHash    NVARCHAR(64)    NOT NULL,
    FullName        NVARCHAR(100)   NOT NULL,
    Email           NVARCHAR(150)   NOT NULL DEFAULT '',
    Role            NVARCHAR(20)    NOT NULL DEFAULT 'Viewer',
    IsActive        BIT             NOT NULL DEFAULT 1,
    CreatedAt       DATETIME        NOT NULL DEFAULT GETDATE(),
    LastLogin       DATETIME        NULL,

    CONSTRAINT PK_Users PRIMARY KEY (UserId),
    CONSTRAINT UQ_Users_Username UNIQUE (Username),
    CONSTRAINT CK_Users_Role CHECK (Role IN ('Admin','Enumerator','Viewer'))
);
GO

-- ═══════════════════════════════════════════════════════════════════════
-- TABLE: Provinces
-- ═══════════════════════════════════════════════════════════════════════
CREATE TABLE Provinces (
    ProvinceId      INT             NOT NULL IDENTITY(1,1),
    ProvinceName    NVARCHAR(100)   NOT NULL,
    ProvinceCode    NVARCHAR(10)    NOT NULL DEFAULT '',

    CONSTRAINT PK_Provinces PRIMARY KEY (ProvinceId),
    CONSTRAINT UQ_Provinces_Name UNIQUE (ProvinceName)
);
GO

-- ═══════════════════════════════════════════════════════════════════════
-- TABLE: Districts
-- ═══════════════════════════════════════════════════════════════════════
CREATE TABLE Districts (
    DistrictId      INT             NOT NULL IDENTITY(1,1),
    ProvinceId      INT             NOT NULL,
    DistrictName    NVARCHAR(100)   NOT NULL,
    DistrictCode    NVARCHAR(10)    NOT NULL DEFAULT '',

    CONSTRAINT PK_Districts PRIMARY KEY (DistrictId),
    CONSTRAINT FK_Districts_Province FOREIGN KEY (ProvinceId)
        REFERENCES Provinces(ProvinceId) ON DELETE CASCADE
);
GO

CREATE INDEX IX_Districts_Province ON Districts(ProvinceId);
GO

-- ═══════════════════════════════════════════════════════════════════════
-- TABLE: UnionCouncils
-- ═══════════════════════════════════════════════════════════════════════
CREATE TABLE UnionCouncils (
    UnionCouncilId      INT             NOT NULL IDENTITY(1,1),
    DistrictId          INT             NOT NULL,
    UnionCouncilName    NVARCHAR(150)   NOT NULL,
    UCCode              NVARCHAR(20)    NOT NULL DEFAULT '',
    UCType              NVARCHAR(10)    NOT NULL DEFAULT 'Urban',

    CONSTRAINT PK_UnionCouncils PRIMARY KEY (UnionCouncilId),
    CONSTRAINT FK_UnionCouncils_District FOREIGN KEY (DistrictId)
        REFERENCES Districts(DistrictId) ON DELETE CASCADE,
    CONSTRAINT CK_UnionCouncils_Type CHECK (UCType IN ('Urban','Rural'))
);
GO

CREATE INDEX IX_UnionCouncils_District ON UnionCouncils(DistrictId);
GO

-- ═══════════════════════════════════════════════════════════════════════
-- TABLE: Households
-- ═══════════════════════════════════════════════════════════════════════
CREATE TABLE Households (
    HouseholdId         INT             NOT NULL IDENTITY(1,1),
    HouseholdCode       NVARCHAR(30)    NOT NULL,
    UnionCouncilId      INT             NOT NULL,
    Address             NVARCHAR(500)   NOT NULL,
    HeadOfHousehold     NVARCHAR(150)   NOT NULL,
    ContactNumber       NVARCHAR(20)    NOT NULL DEFAULT '',
    HousingType         NVARCHAR(30)    NOT NULL DEFAULT 'Pucca',
    NumRooms            INT             NOT NULL DEFAULT 1,
    OwnershipStatus     NVARCHAR(30)    NOT NULL DEFAULT 'Owned',
    WaterSource         NVARCHAR(50)    NOT NULL DEFAULT 'Tap Water',
    ElectricitySource   NVARCHAR(50)    NOT NULL DEFAULT 'WAPDA/Grid',
    HasSanitation       BIT             NOT NULL DEFAULT 0,
    HasInternet         BIT             NOT NULL DEFAULT 0,
    MonthlyIncome       DECIMAL(12,2)   NOT NULL DEFAULT 0,
    EnumeratorId        INT             NULL,
    SurveyDate          DATETIME        NOT NULL DEFAULT GETDATE(),
    Status              NVARCHAR(20)    NOT NULL DEFAULT 'Pending',
    CreatedAt           DATETIME        NOT NULL DEFAULT GETDATE(),
    UpdatedAt           DATETIME        NOT NULL DEFAULT GETDATE(),

    CONSTRAINT PK_Households PRIMARY KEY (HouseholdId),
    CONSTRAINT UQ_Households_Code UNIQUE (HouseholdCode),
    CONSTRAINT FK_Households_UC FOREIGN KEY (UnionCouncilId)
        REFERENCES UnionCouncils(UnionCouncilId),
    CONSTRAINT FK_Households_Enumerator FOREIGN KEY (EnumeratorId)
        REFERENCES Users(UserId) ON DELETE SET NULL,
    CONSTRAINT CK_Households_Status CHECK (Status IN ('Pending','Complete','Verified')),
    CONSTRAINT CK_Households_Rooms CHECK (NumRooms >= 1),
    CONSTRAINT CK_Households_Income CHECK (MonthlyIncome >= 0)
);
GO

CREATE INDEX IX_Households_UC       ON Households(UnionCouncilId);
CREATE INDEX IX_Households_Status   ON Households(Status);
CREATE INDEX IX_Households_Date     ON Households(SurveyDate);
CREATE INDEX IX_Households_Head     ON Households(HeadOfHousehold);
GO

-- ═══════════════════════════════════════════════════════════════════════
-- TABLE: Persons
-- ═══════════════════════════════════════════════════════════════════════
CREATE TABLE Persons (
    PersonId        INT             NOT NULL IDENTITY(1,1),
    HouseholdId     INT             NOT NULL,
    FirstName       NVARCHAR(100)   NOT NULL,
    LastName        NVARCHAR(100)   NOT NULL,
    CNICNumber      NVARCHAR(15)    NOT NULL DEFAULT '',
    Gender          NVARCHAR(10)    NOT NULL,
    DateOfBirth     DATE            NOT NULL,
    Age             INT             NOT NULL DEFAULT 0,
    MaritalStatus   NVARCHAR(20)    NOT NULL DEFAULT 'Single',
    Relationship    NVARCHAR(30)    NOT NULL DEFAULT 'Head',
    Education       NVARCHAR(30)    NOT NULL DEFAULT 'None',
    Occupation      NVARCHAR(50)    NOT NULL DEFAULT 'Unemployed',
    Disability      NVARCHAR(30)    NOT NULL DEFAULT 'None',
    Nationality     NVARCHAR(50)    NOT NULL DEFAULT 'Pakistani',
    Religion        NVARCHAR(30)    NOT NULL DEFAULT 'Islam',
    MotherTongue    NVARCHAR(50)    NOT NULL DEFAULT 'Urdu',
    CreatedAt       DATETIME        NOT NULL DEFAULT GETDATE(),

    CONSTRAINT PK_Persons PRIMARY KEY (PersonId),
    CONSTRAINT FK_Persons_Household FOREIGN KEY (HouseholdId)
        REFERENCES Households(HouseholdId) ON DELETE CASCADE,
    CONSTRAINT CK_Persons_Gender CHECK (Gender IN ('Male','Female','Other')),
    CONSTRAINT CK_Persons_Age CHECK (Age >= 0 AND Age <= 130),
    CONSTRAINT CK_Persons_MaritalStatus CHECK (MaritalStatus IN ('Single','Married','Divorced','Widowed'))
);
GO

CREATE INDEX IX_Persons_Household   ON Persons(HouseholdId);
CREATE INDEX IX_Persons_Gender      ON Persons(Gender);
CREATE INDEX IX_Persons_Age         ON Persons(Age);
CREATE INDEX IX_Persons_CNIC        ON Persons(CNICNumber);
CREATE INDEX IX_Persons_Education   ON Persons(Education);
CREATE INDEX IX_Persons_Occupation  ON Persons(Occupation);
GO

-- ═══════════════════════════════════════════════════════════════════════
-- TABLE: AuditLog  (optional — tracks data changes)
-- ═══════════════════════════════════════════════════════════════════════
CREATE TABLE AuditLog (
    LogId           INT             NOT NULL IDENTITY(1,1),
    UserId          INT             NULL,
    Action          NVARCHAR(20)    NOT NULL,   -- INSERT, UPDATE, DELETE
    TableName       NVARCHAR(50)    NOT NULL,
    RecordId        INT             NULL,
    Description     NVARCHAR(500)   NOT NULL DEFAULT '',
    CreatedAt       DATETIME        NOT NULL DEFAULT GETDATE(),

    CONSTRAINT PK_AuditLog PRIMARY KEY (LogId),
    CONSTRAINT FK_AuditLog_User FOREIGN KEY (UserId)
        REFERENCES Users(UserId) ON DELETE SET NULL
);
GO

-- ═══════════════════════════════════════════════════════════════════════
-- TRIGGERS — Auto-update UpdatedAt on Households
-- ═══════════════════════════════════════════════════════════════════════
CREATE TRIGGER TR_Households_UpdatedAt
ON Households
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Households
    SET UpdatedAt = GETDATE()
    WHERE HouseholdId IN (SELECT HouseholdId FROM inserted);
END;
GO

-- ═══════════════════════════════════════════════════════════════════════
-- VIEWS
-- ═══════════════════════════════════════════════════════════════════════

-- View: Full Population Details
CREATE VIEW vw_PopulationDetails AS
SELECT
    p.PersonId,
    p.FirstName + ' ' + p.LastName AS FullName,
    p.CNICNumber,
    p.Gender,
    p.Age,
    p.MaritalStatus,
    p.Relationship,
    p.Education,
    p.Occupation,
    p.Disability,
    p.Religion,
    p.MotherTongue,
    h.HouseholdCode,
    h.HeadOfHousehold,
    h.Status AS HouseholdStatus,
    uc.UnionCouncilName,
    uc.UCType,
    d.DistrictName,
    pr.ProvinceName
FROM Persons p
INNER JOIN Households h ON p.HouseholdId = h.HouseholdId
INNER JOIN UnionCouncils uc ON h.UnionCouncilId = uc.UnionCouncilId
INNER JOIN Districts d ON uc.DistrictId = d.DistrictId
INNER JOIN Provinces pr ON d.ProvinceId = pr.ProvinceId;
GO

-- View: Household Summary
CREATE VIEW vw_HouseholdSummary AS
SELECT
    h.HouseholdId,
    h.HouseholdCode,
    h.HeadOfHousehold,
    h.Address,
    h.HousingType,
    h.OwnershipStatus,
    h.MonthlyIncome,
    h.Status,
    h.SurveyDate,
    uc.UnionCouncilName,
    uc.UCType,
    d.DistrictName,
    pr.ProvinceName,
    u.FullName AS EnumeratorName,
    COUNT(p.PersonId) AS MemberCount,
    SUM(CASE WHEN p.Gender = 'Male' THEN 1 ELSE 0 END) AS MaleCount,
    SUM(CASE WHEN p.Gender = 'Female' THEN 1 ELSE 0 END) AS FemaleCount
FROM Households h
INNER JOIN UnionCouncils uc ON h.UnionCouncilId = uc.UnionCouncilId
INNER JOIN Districts d ON uc.DistrictId = d.DistrictId
INNER JOIN Provinces pr ON d.ProvinceId = pr.ProvinceId
LEFT JOIN Users u ON h.EnumeratorId = u.UserId
LEFT JOIN Persons p ON h.HouseholdId = p.HouseholdId
GROUP BY h.HouseholdId, h.HouseholdCode, h.HeadOfHousehold, h.Address,
         h.HousingType, h.OwnershipStatus, h.MonthlyIncome, h.Status,
         h.SurveyDate, uc.UnionCouncilName, uc.UCType,
         d.DistrictName, pr.ProvinceName, u.FullName;
GO

-- View: District Statistics
CREATE VIEW vw_DistrictStats AS
SELECT
    d.DistrictId,
    d.DistrictName,
    pr.ProvinceName,
    COUNT(DISTINCT uc.UnionCouncilId)   AS TotalUCs,
    COUNT(DISTINCT h.HouseholdId)       AS TotalHouseholds,
    COUNT(p.PersonId)                   AS TotalPopulation,
    SUM(CASE WHEN p.Gender='Male'   THEN 1 ELSE 0 END) AS Males,
    SUM(CASE WHEN p.Gender='Female' THEN 1 ELSE 0 END) AS Females,
    AVG(CAST(p.Age AS FLOAT))           AS AvgAge,
    AVG(h.MonthlyIncome)                AS AvgHouseholdIncome
FROM Districts d
INNER JOIN Provinces pr ON d.ProvinceId = pr.ProvinceId
LEFT JOIN UnionCouncils uc ON d.DistrictId = uc.DistrictId
LEFT JOIN Households h ON uc.UnionCouncilId = h.UnionCouncilId
LEFT JOIN Persons p ON h.HouseholdId = p.HouseholdId
GROUP BY d.DistrictId, d.DistrictName, pr.ProvinceName;
GO

-- ═══════════════════════════════════════════════════════════════════════
-- STORED PROCEDURES
-- ═══════════════════════════════════════════════════════════════════════

-- SP: Get Dashboard Statistics
CREATE PROCEDURE sp_GetDashboardStats
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        (SELECT COUNT(*) FROM Households)                                           AS TotalHouseholds,
        (SELECT COUNT(*) FROM Persons)                                              AS TotalPersons,
        (SELECT COUNT(*) FROM Persons WHERE Gender = 'Male')                        AS TotalMales,
        (SELECT COUNT(*) FROM Persons WHERE Gender = 'Female')                      AS TotalFemales,
        (SELECT COUNT(*) FROM Districts)                                            AS TotalDistricts,
        (SELECT COUNT(*) FROM UnionCouncils)                                        AS TotalUCs,
        (SELECT COUNT(*) FROM Households
         WHERE MONTH(SurveyDate) = MONTH(GETDATE())
         AND YEAR(SurveyDate) = YEAR(GETDATE()))                                    AS SurveysThisMonth,
        (SELECT COUNT(*) FROM Households WHERE Status = 'Pending')                  AS PendingSurveys,
        (SELECT COUNT(*) FROM Households WHERE Status = 'Complete')                 AS CompleteSurveys,
        (SELECT COUNT(*) FROM Households WHERE Status = 'Verified')                 AS VerifiedSurveys,
        (SELECT COUNT(DISTINCT HouseholdId) FROM Persons
         WHERE Education NOT IN ('None','Illiterate')
         AND Age >= 15) * 100.0 /
        NULLIF((SELECT COUNT(*) FROM Persons WHERE Age >= 15), 0)                   AS LiteracyRate;
END;
GO

-- SP: Search Households
CREATE PROCEDURE sp_SearchHouseholds
    @Search         NVARCHAR(200) = NULL,
    @UnionCouncilId INT           = NULL,
    @DistrictId     INT           = NULL,
    @Status         NVARCHAR(20)  = NULL,
    @FromDate       DATETIME      = NULL,
    @ToDate         DATETIME      = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        h.HouseholdId,
        h.HouseholdCode,
        h.HeadOfHousehold,
        h.Address,
        h.ContactNumber,
        h.HousingType,
        h.NumRooms,
        h.OwnershipStatus,
        h.WaterSource,
        h.ElectricitySource,
        h.HasSanitation,
        h.HasInternet,
        h.MonthlyIncome,
        h.Status,
        h.SurveyDate,
        uc.UnionCouncilName,
        d.DistrictName,
        pr.ProvinceName,
        u.FullName AS EnumeratorName,
        COUNT(p.PersonId) AS MemberCount
    FROM Households h
    INNER JOIN UnionCouncils uc ON h.UnionCouncilId = uc.UnionCouncilId
    INNER JOIN Districts d ON uc.DistrictId = d.DistrictId
    INNER JOIN Provinces pr ON d.ProvinceId = pr.ProvinceId
    LEFT JOIN Users u ON h.EnumeratorId = u.UserId
    LEFT JOIN Persons p ON h.HouseholdId = p.HouseholdId
    WHERE
        (@Search IS NULL OR
         h.HouseholdCode LIKE '%' + @Search + '%' OR
         h.HeadOfHousehold LIKE '%' + @Search + '%' OR
         h.Address LIKE '%' + @Search + '%')
        AND (@UnionCouncilId IS NULL OR h.UnionCouncilId = @UnionCouncilId)
        AND (@DistrictId IS NULL OR uc.DistrictId = @DistrictId)
        AND (@Status IS NULL OR h.Status = @Status)
        AND (@FromDate IS NULL OR h.SurveyDate >= @FromDate)
        AND (@ToDate IS NULL OR h.SurveyDate <= @ToDate)
    GROUP BY
        h.HouseholdId, h.HouseholdCode, h.HeadOfHousehold, h.Address, h.ContactNumber,
        h.HousingType, h.NumRooms, h.OwnershipStatus, h.WaterSource, h.ElectricitySource,
        h.HasSanitation, h.HasInternet, h.MonthlyIncome, h.Status, h.SurveyDate,
        uc.UnionCouncilName, d.DistrictName, pr.ProvinceName, u.FullName
    ORDER BY h.SurveyDate DESC;
END;
GO

-- SP: Population Report by District
CREATE PROCEDURE sp_PopulationReportByDistrict
    @DistrictId INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        pr.ProvinceName,
        d.DistrictName,
        uc.UnionCouncilName,
        uc.UCType,
        COUNT(DISTINCT h.HouseholdId)                                               AS Households,
        COUNT(p.PersonId)                                                           AS TotalPopulation,
        SUM(CASE WHEN p.Gender = 'Male'   THEN 1 ELSE 0 END)                       AS Males,
        SUM(CASE WHEN p.Gender = 'Female' THEN 1 ELSE 0 END)                       AS Females,
        AVG(CAST(p.Age AS FLOAT))                                                   AS AvgAge,
        SUM(CASE WHEN p.Education NOT IN ('None') AND p.Age >= 15 THEN 1 ELSE 0 END)
            * 100.0 / NULLIF(SUM(CASE WHEN p.Age >= 15 THEN 1 ELSE 0 END), 0)      AS LiteracyRate,
        AVG(h.MonthlyIncome)                                                        AS AvgIncome
    FROM UnionCouncils uc
    INNER JOIN Districts d ON uc.DistrictId = d.DistrictId
    INNER JOIN Provinces pr ON d.ProvinceId = pr.ProvinceId
    LEFT JOIN Households h ON uc.UnionCouncilId = h.UnionCouncilId
    LEFT JOIN Persons p ON h.HouseholdId = p.HouseholdId
    WHERE (@DistrictId IS NULL OR d.DistrictId = @DistrictId)
    GROUP BY pr.ProvinceName, d.DistrictName, uc.UnionCouncilName, uc.UCType
    ORDER BY pr.ProvinceName, d.DistrictName, uc.UnionCouncilName;
END;
GO

-- SP: Age-Gender Pyramid data
CREATE PROCEDURE sp_AgePyramid
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        CASE
            WHEN Age BETWEEN  0 AND  4 THEN '0-4'
            WHEN Age BETWEEN  5 AND  9 THEN '5-9'
            WHEN Age BETWEEN 10 AND 14 THEN '10-14'
            WHEN Age BETWEEN 15 AND 19 THEN '15-19'
            WHEN Age BETWEEN 20 AND 24 THEN '20-24'
            WHEN Age BETWEEN 25 AND 29 THEN '25-29'
            WHEN Age BETWEEN 30 AND 34 THEN '30-34'
            WHEN Age BETWEEN 35 AND 39 THEN '35-39'
            WHEN Age BETWEEN 40 AND 44 THEN '40-44'
            WHEN Age BETWEEN 45 AND 49 THEN '45-49'
            WHEN Age BETWEEN 50 AND 54 THEN '50-54'
            WHEN Age BETWEEN 55 AND 59 THEN '55-59'
            WHEN Age BETWEEN 60 AND 64 THEN '60-64'
            ELSE '65+'
        END AS AgeGroup,
        SUM(CASE WHEN Gender = 'Male'   THEN 1 ELSE 0 END) AS Males,
        SUM(CASE WHEN Gender = 'Female' THEN 1 ELSE 0 END) AS Females
    FROM Persons
    GROUP BY
        CASE
            WHEN Age BETWEEN  0 AND  4 THEN '0-4'
            WHEN Age BETWEEN  5 AND  9 THEN '5-9'
            WHEN Age BETWEEN 10 AND 14 THEN '10-14'
            WHEN Age BETWEEN 15 AND 19 THEN '15-19'
            WHEN Age BETWEEN 20 AND 24 THEN '20-24'
            WHEN Age BETWEEN 25 AND 29 THEN '25-29'
            WHEN Age BETWEEN 30 AND 34 THEN '30-34'
            WHEN Age BETWEEN 35 AND 39 THEN '35-39'
            WHEN Age BETWEEN 40 AND 44 THEN '40-44'
            WHEN Age BETWEEN 45 AND 49 THEN '45-49'
            WHEN Age BETWEEN 50 AND 54 THEN '50-54'
            WHEN Age BETWEEN 55 AND 59 THEN '55-59'
            WHEN Age BETWEEN 60 AND 64 THEN '60-64'
            ELSE '65+'
        END
    ORDER BY MIN(Age);
END;
GO

-- ═══════════════════════════════════════════════════════════════════════
-- SEED DATA
-- ═══════════════════════════════════════════════════════════════════════

-- Default Admin User  (password: admin123)
INSERT INTO Users (Username, PasswordHash, FullName, Email, Role, IsActive, CreatedAt)
VALUES (
    'admin',
    UPPER(CONVERT(NVARCHAR(64), HASHBYTES('SHA2_256', 'admin123CensusSalt2024'), 2)),
    'System Administrator',
    'admin@census.gov.pk',
    'Admin',
    1,
    GETDATE()
);

-- Sample Enumerator  (password: enum123)
INSERT INTO Users (Username, PasswordHash, FullName, Email, Role, IsActive, CreatedAt)
VALUES (
    'enumerator1',
    UPPER(CONVERT(NVARCHAR(64), HASHBYTES('SHA2_256', 'enum123CensusSalt2024'), 2)),
    'Muhammad Ali Khan',
    'ali.khan@census.gov.pk',
    'Enumerator',
    1,
    GETDATE()
);

-- ─────────────────────────────────────────────────────────────────────
-- Provinces of Pakistan
-- ─────────────────────────────────────────────────────────────────────
INSERT INTO Provinces (ProvinceName, ProvinceCode) VALUES
    ('Punjab',                      'PB'),
    ('Sindh',                       'SD'),
    ('Khyber Pakhtunkhwa',          'KP'),
    ('Balochistan',                 'BL'),
    ('Gilgit-Baltistan',            'GB'),
    ('Azad Jammu & Kashmir',        'AJK'),
    ('Islamabad Capital Territory', 'ICT');

-- ─────────────────────────────────────────────────────────────────────
-- Districts  (ProvinceId looked up by name — safe regardless of IDENTITY seed)
-- ─────────────────────────────────────────────────────────────────────
INSERT INTO Districts (ProvinceId, DistrictName, DistrictCode)
SELECT ProvinceId, D.DistrictName, D.DistrictCode
FROM Provinces p
JOIN (VALUES
    ('Punjab',                      'Lahore',       'LHR'),
    ('Punjab',                      'Faisalabad',   'FSD'),
    ('Punjab',                      'Rawalpindi',   'RWP'),
    ('Punjab',                      'Gujranwala',   'GRW'),
    ('Punjab',                      'Multan',       'MLT'),
    ('Punjab',                      'Sialkot',      'SKT'),
    ('Punjab',                      'Bahawalpur',   'BWP'),
    ('Punjab',                      'Sargodha',     'SGD'),
    ('Sindh',                       'Karachi',      'KHI'),
    ('Sindh',                       'Hyderabad',    'HYD'),
    ('Sindh',                       'Sukkur',       'SKR'),
    ('Sindh',                       'Larkana',      'LRK'),
    ('Khyber Pakhtunkhwa',          'Peshawar',     'PSW'),
    ('Khyber Pakhtunkhwa',          'Mardan',       'MRD'),
    ('Khyber Pakhtunkhwa',          'Abbottabad',   'ABD'),
    ('Khyber Pakhtunkhwa',          'Swat',         'SWT'),
    ('Balochistan',                 'Quetta',       'QTA'),
    ('Balochistan',                 'Gwadar',       'GWD'),
    ('Islamabad Capital Territory', 'Islamabad',    'ISB')
) AS D(ProvinceName, DistrictName, DistrictCode)
  ON p.ProvinceName = D.ProvinceName;

-- ─────────────────────────────────────────────────────────────────────
-- Union Councils  (DistrictId looked up by name)
-- ─────────────────────────────────────────────────────────────────────
INSERT INTO UnionCouncils (DistrictId, UnionCouncilName, UCCode, UCType)
SELECT d.DistrictId, U.UnionCouncilName, U.UCCode, U.UCType
FROM Districts d
JOIN (VALUES
    ('Lahore',    'Gulberg I',            'UC-LHR-001', 'Urban'),
    ('Lahore',    'Model Town',           'UC-LHR-002', 'Urban'),
    ('Lahore',    'Johar Town',           'UC-LHR-003', 'Urban'),
    ('Lahore',    'Defence Housing Auth', 'UC-LHR-004', 'Urban'),
    ('Lahore',    'Raiwind',              'UC-LHR-005', 'Rural'),
    ('Lahore',    'Kot Radha Kishan',     'UC-LHR-006', 'Rural'),
    ('Karachi',   'Clifton',              'UC-KHI-001', 'Urban'),
    ('Karachi',   'Saddar',               'UC-KHI-002', 'Urban'),
    ('Karachi',   'Gulshan-e-Iqbal',      'UC-KHI-003', 'Urban'),
    ('Karachi',   'Korangi',              'UC-KHI-004', 'Urban'),
    ('Islamabad', 'F-6 / F-7',            'UC-ISB-001', 'Urban'),
    ('Islamabad', 'G-6 / G-7',            'UC-ISB-002', 'Urban'),
    ('Islamabad', 'E-7 / E-8',            'UC-ISB-003', 'Urban'),
    ('Islamabad', 'Bari Imam',            'UC-ISB-004', 'Rural'),
    ('Peshawar',  'Cantonment',           'UC-PSW-001', 'Urban'),
    ('Peshawar',  'Hayatabad',            'UC-PSW-002', 'Urban'),
    ('Peshawar',  'Badhber',              'UC-PSW-003', 'Rural')
) AS U(DistrictName, UnionCouncilName, UCCode, UCType)
  ON d.DistrictName = U.DistrictName;

-- ─────────────────────────────────────────────────────────────────────
-- Sample Households  (UnionCouncilId and EnumeratorId looked up by name)
-- ─────────────────────────────────────────────────────────────────────
INSERT INTO Households (HouseholdCode, UnionCouncilId, Address, HeadOfHousehold, ContactNumber,
    HousingType, NumRooms, OwnershipStatus, WaterSource, ElectricitySource,
    HasSanitation, HasInternet, MonthlyIncome, EnumeratorId, SurveyDate, Status)
SELECT
    H.HouseholdCode,
    uc.UnionCouncilId,
    H.Address,
    H.HeadOfHousehold,
    H.ContactNumber,
    H.HousingType,
    H.NumRooms,
    H.OwnershipStatus,
    H.WaterSource,
    H.ElectricitySource,
    H.HasSanitation,
    H.HasInternet,
    H.MonthlyIncome,
    u.UserId,
    H.SurveyDate,
    H.Status
FROM (VALUES
    ('HH-0001-000001', 'Gulberg I',            'House 12, Street 5, Gulberg I, Lahore',       'Ahmad Raza',     '0300-1234567', 'Pucca',     4, 'Owned',  'Tap Water', 'WAPDA/Grid', 1, 1, 75000.00,  'enumerator1', '2024-03-15', 'Verified'),
    ('HH-0001-000002', 'Gulberg I',            'House 45-A, Model Town Extension, Lahore',    'Farida Bibi',    '0321-9876543', 'Pucca',     6, 'Owned',  'Tap Water', 'WAPDA/Grid', 1, 1, 150000.00, 'enumerator1', '2024-03-16', 'Complete'),
    ('HH-0001-000003', 'Model Town',           'Plot 7, Block C, Model Town, Lahore',         'Muhammad Yasir', '0333-5551234', 'Pucca',     5, 'Rented', 'Tap Water', 'WAPDA/Grid', 1, 1, 45000.00,  'enumerator1', '2024-03-17', 'Complete'),
    ('HH-0001-000004', 'Raiwind',              'Village Raiwind, Near Main Bazar',            'Abdul Qadir',    '0345-7894561', 'Katcha',    2, 'Owned',  'Hand Pump', 'WAPDA/Grid', 0, 0, 18000.00,  'enumerator1', '2024-03-18', 'Pending'),
    ('HH-0009-000001', 'Clifton',              'Flat 3B, Block 6 PECHS, Karachi',             'Rizwan Hashmi',  '0311-4567890', 'Apartment', 3, 'Rented', 'Tap Water', 'WAPDA/Grid', 1, 1, 60000.00,  'enumerator1', '2024-04-01', 'Complete'),
    ('HH-0019-000001', 'F-6 / F-7',           'House 22, Street 10, F-7/2, Islamabad',       'Dr. Sana Malik', '0300-9998887', 'Pucca',     5, 'Owned',  'Tap Water', 'WAPDA/Grid', 1, 1, 200000.00, 'enumerator1', '2024-04-05', 'Verified')
) AS H(HouseholdCode, UCName, Address, HeadOfHousehold, ContactNumber,
       HousingType, NumRooms, OwnershipStatus, WaterSource, ElectricitySource,
       HasSanitation, HasInternet, MonthlyIncome, EnumeratorUsername, SurveyDate, Status)
JOIN UnionCouncils uc ON uc.UnionCouncilName = H.UCName
JOIN Users         u  ON u.Username          = H.EnumeratorUsername;

-- ─────────────────────────────────────────────────────────────────────
-- Sample Persons  (HouseholdId looked up by HouseholdCode)
-- ─────────────────────────────────────────────────────────────────────
INSERT INTO Persons (HouseholdId, FirstName, LastName, CNICNumber, Gender, DateOfBirth, Age,
    MaritalStatus, Relationship, Education, Occupation, Disability, Nationality, Religion, MotherTongue)
SELECT
    h.HouseholdId,
    P.FirstName, P.LastName, P.CNICNumber, P.Gender, P.DateOfBirth, P.Age,
    P.MaritalStatus, P.Relationship, P.Education, P.Occupation,
    P.Disability, P.Nationality, P.Religion, P.MotherTongue
FROM (VALUES
    -- Household 1 — Ahmad Raza family (Gulberg I, Lahore)
    ('HH-0001-000001', 'Ahmad',    'Raza',    '35201-1234567-1', 'Male',   '1975-05-10', 51, 'Married', 'Head',            'Bachelor',      'Government Employee', 'None', 'Pakistani', 'Islam', 'Punjabi'),
    ('HH-0001-000001', 'Nadia',    'Ahmad',   '35201-7654321-8', 'Female', '1980-09-22', 45, 'Married', 'Spouse',          'Matriculation', 'Housewife',           'None', 'Pakistani', 'Islam', 'Punjabi'),
    ('HH-0001-000001', 'Bilal',    'Ahmad',   '35201-1112223-3', 'Male',   '2003-01-15', 23, 'Single',  'Son',             'Intermediate',  'Student',             'None', 'Pakistani', 'Islam', 'Punjabi'),
    ('HH-0001-000001', 'Hira',     'Ahmad',   '35201-3334445-6', 'Female', '2006-07-30', 19, 'Single',  'Daughter',        'Matriculation', 'Student',             'None', 'Pakistani', 'Islam', 'Punjabi'),
    ('HH-0001-000001', 'Tariq',    'Raza',    '35201-9998887-7', 'Male',   '1945-03-01', 81, 'Married', 'Father',          'Primary',       'Retired',             'None', 'Pakistani', 'Islam', 'Punjabi'),
    -- Household 2 — Farida Bibi family (Gulberg I, Lahore)
    ('HH-0001-000002', 'Farida',   'Bibi',    '35201-2223334-5', 'Female', '1968-12-01', 57, 'Widowed', 'Head',            'Intermediate',  'Self Employed',       'None', 'Pakistani', 'Islam', 'Punjabi'),
    ('HH-0001-000002', 'Kamran',   'Ahmed',   '35201-4445556-7', 'Male',   '1991-04-20', 35, 'Married', 'Son',             'Master',        'Private Employee',    'None', 'Pakistani', 'Islam', 'Punjabi'),
    ('HH-0001-000002', 'Sana',     'Kamran',  '35201-6667778-9', 'Female', '1994-08-15', 31, 'Married', 'Daughter-in-Law', 'Bachelor',      'Housewife',           'None', 'Pakistani', 'Islam', 'Punjabi'),
    ('HH-0001-000002', 'Zara',     'Kamran',  '35201-8889990-1', 'Female', '2018-02-28',  8, 'Single',  'Granddaughter',   'None',          'Student',             'None', 'Pakistani', 'Islam', 'Punjabi'),
    -- Household 3 — Muhammad Yasir family (Model Town, Lahore)
    ('HH-0001-000003', 'Muhammad', 'Yasir',   '35201-1122334-5', 'Male',   '1985-07-14', 40, 'Married', 'Head',            'Bachelor',      'Business',            'None', 'Pakistani', 'Islam', 'Urdu'),
    ('HH-0001-000003', 'Rabia',    'Yasir',   '35201-5566778-9', 'Female', '1988-11-30', 37, 'Married', 'Spouse',          'Matriculation', 'Housewife',           'None', 'Pakistani', 'Islam', 'Urdu'),
    ('HH-0001-000003', 'Omar',     'Yasir',   '35201-9900112-3', 'Male',   '2010-06-05', 16, 'Single',  'Son',             'Primary',       'Student',             'None', 'Pakistani', 'Islam', 'Urdu'),
    -- Household 4 — Rural (Raiwind, Lahore)
    ('HH-0001-000004', 'Abdul',    'Qadir',   '35201-4433221-1', 'Male',   '1960-01-01', 66, 'Married', 'Head',            'None',          'Farmer',              'None', 'Pakistani', 'Islam', 'Punjabi'),
    ('HH-0001-000004', 'Sakina',   'Bibi',    '35201-1122112-2', 'Female', '1965-06-15', 60, 'Married', 'Spouse',          'None',          'Housewife',           'None', 'Pakistani', 'Islam', 'Punjabi'),
    ('HH-0001-000004', 'Imran',    'Abdul',   '35201-2233443-3', 'Male',   '1990-09-09', 35, 'Married', 'Son',             'Matriculation', 'Daily Wage Worker',   'None', 'Pakistani', 'Islam', 'Punjabi'),
    ('HH-0001-000004', 'Razia',    'Imran',   '35201-3344554-4', 'Female', '1993-03-20', 33, 'Married', 'Daughter-in-Law', 'Primary',       'Housewife',           'None', 'Pakistani', 'Islam', 'Punjabi'),
    ('HH-0001-000004', 'Adnan',    'Imran',   '35201-4455665-5', 'Male',   '2015-12-10', 10, 'Single',  'Grandson',        'None',          'Student',             'None', 'Pakistani', 'Islam', 'Punjabi'),
    ('HH-0001-000004', 'Aqsa',     'Imran',   '35201-5566776-6', 'Female', '2019-04-02',  7, 'Single',  'Granddaughter',   'None',          'Student',             'None', 'Pakistani', 'Islam', 'Punjabi'),
    -- Household 5 — Rizwan Hashmi family (Clifton, Karachi)
    ('HH-0009-000001', 'Rizwan',   'Hashmi',  '42201-1234568-9', 'Male',   '1982-08-25', 43, 'Married', 'Head',            'Bachelor',      'Private Employee',    'None', 'Pakistani', 'Islam', 'Urdu'),
    ('HH-0009-000001', 'Salma',    'Rizwan',  '42201-9876544-5', 'Female', '1986-02-14', 40, 'Married', 'Spouse',          'Intermediate',  'Housewife',           'None', 'Pakistani', 'Islam', 'Urdu'),
    ('HH-0009-000001', 'Hassan',   'Rizwan',  '42201-1111234-6', 'Male',   '2008-10-30', 17, 'Single',  'Son',             'Matriculation', 'Student',             'None', 'Pakistani', 'Islam', 'Urdu'),
    -- Household 6 — Sana Malik family (F-6/F-7, Islamabad)
    ('HH-0019-000001', 'Sana',     'Malik',   '61101-9998881-7', 'Female', '1978-03-10', 48, 'Married', 'Head',            'PhD',           'Government Employee', 'None', 'Pakistani', 'Islam', 'Urdu'),
    ('HH-0019-000001', 'Tariq',    'Malik',   '61101-1112224-8', 'Male',   '1976-07-22', 50, 'Married', 'Spouse',          'Master',        'Government Employee', 'None', 'Pakistani', 'Islam', 'Urdu'),
    ('HH-0019-000001', 'Ayesha',   'Tariq',   '61101-2223335-9', 'Female', '2002-11-05', 23, 'Single',  'Daughter',        'Bachelor',      'Student',             'None', 'Pakistani', 'Islam', 'Urdu'),
    ('HH-0019-000001', 'Usman',    'Tariq',   '61101-3334446-0', 'Male',   '2005-04-18', 21, 'Single',  'Son',             'Intermediate',  'Student',             'None', 'Pakistani', 'Islam', 'Urdu')
) AS P(HouseholdCode, FirstName, LastName, CNICNumber, Gender, DateOfBirth, Age,
       MaritalStatus, Relationship, Education, Occupation, Disability, Nationality, Religion, MotherTongue)
JOIN Households h ON h.HouseholdCode = P.HouseholdCode;

GO

-- ═══════════════════════════════════════════════════════════════════════
-- VERIFY SETUP
-- ═══════════════════════════════════════════════════════════════════════
PRINT '═══════════════════════════════════════════════════════';
PRINT ' Census Management System — Database Setup Complete!   ';
PRINT '═══════════════════════════════════════════════════════';
PRINT '';
PRINT 'Tables Created:';
SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE='BASE TABLE' ORDER BY TABLE_NAME;

PRINT '';
PRINT 'Default Login Credentials:';
PRINT '  Admin:      admin       / admin123';
PRINT '  Enumerator: enumerator1 / enum123';
PRINT '';
PRINT 'Sample data inserted:';
SELECT 'Provinces'    AS Entity, COUNT(*) AS Count FROM Provinces   UNION ALL
SELECT 'Districts'    AS Entity, COUNT(*) AS Count FROM Districts    UNION ALL
SELECT 'UnionCouncils',           COUNT(*)           FROM UnionCouncils UNION ALL
SELECT 'Households',              COUNT(*)           FROM Households    UNION ALL
SELECT 'Persons',                 COUNT(*)           FROM Persons;
GO
