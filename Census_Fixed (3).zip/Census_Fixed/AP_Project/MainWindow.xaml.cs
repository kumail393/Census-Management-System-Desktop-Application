using System.Windows;
namespace AP_Project
{
    public partial class MainWindow : Window
    {
        public MainWindow() { InitializeComponent(); }
    }
}
