using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace AP_Project.Models
{
    public abstract class BaseModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    public class User : BaseModel
    {
        public int UserId { get; set; }
        public string Username { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Role { get; set; } = "Viewer";
        public bool IsActive { get; set; } = true;
        public DateTime CreatedAt { get; set; }
        public DateTime? LastLogin { get; set; }
    }

    public class Province : BaseModel
    {
        public int ProvinceId { get; set; }
        public string ProvinceName { get; set; } = string.Empty;
        public string ProvinceCode { get; set; } = string.Empty;
    }

    public class District : BaseModel
    {
        public int DistrictId { get; set; }
        public int ProvinceId { get; set; }
        public string ProvinceName { get; set; } = string.Empty;
        public string DistrictName { get; set; } = string.Empty;
        public string DistrictCode { get; set; } = string.Empty;
    }

    public class UnionCouncil : BaseModel
    {
        public int UnionCouncilId { get; set; }
        public int DistrictId { get; set; }
        public string DistrictName { get; set; } = string.Empty;
        public string UnionCouncilName { get; set; } = string.Empty;
        public string UCCode { get; set; } = string.Empty;
        public string UCType { get; set; } = string.Empty;
    }

    public class Household : BaseModel
    {
        private int _householdId;
        private string _householdCode = string.Empty;
        private int _unionCouncilId;
        private string _ucName = string.Empty;
        private string _address = string.Empty;
        private string _headOfHousehold = string.Empty;
        private string _contactNumber = string.Empty;
        private string _housingType = string.Empty;
        private int _numRooms;
        private string _ownershipStatus = string.Empty;
        private string _waterSource = string.Empty;
        private string _electricitySource = string.Empty;
        private bool _hasSanitation;
        private bool _hasInternet;
        private decimal _monthlyIncome;
        private int _enumeratorId;
        private string _enumeratorName = string.Empty;
        private DateTime _surveyDate;
        private string _status = string.Empty;
        private int _memberCount;

        public int HouseholdId { get => _householdId; set { _householdId = value; OnPropertyChanged(); } }
        public string HouseholdCode { get => _householdCode; set { _householdCode = value; OnPropertyChanged(); } }
        public int UnionCouncilId { get => _unionCouncilId; set { _unionCouncilId = value; OnPropertyChanged(); } }
        public string UCName { get => _ucName; set { _ucName = value; OnPropertyChanged(); } }
        public string Address { get => _address; set { _address = value; OnPropertyChanged(); } }
        public string HeadOfHousehold { get => _headOfHousehold; set { _headOfHousehold = value; OnPropertyChanged(); } }
        public string ContactNumber { get => _contactNumber; set { _contactNumber = value; OnPropertyChanged(); } }
        public string HousingType { get => _housingType; set { _housingType = value; OnPropertyChanged(); } }
        public int NumRooms { get => _numRooms; set { _numRooms = value; OnPropertyChanged(); } }
        public string OwnershipStatus { get => _ownershipStatus; set { _ownershipStatus = value; OnPropertyChanged(); } }
        public string WaterSource { get => _waterSource; set { _waterSource = value; OnPropertyChanged(); } }
        public string ElectricitySource { get => _electricitySource; set { _electricitySource = value; OnPropertyChanged(); } }
        public bool HasSanitation { get => _hasSanitation; set { _hasSanitation = value; OnPropertyChanged(); } }
        public bool HasInternet { get => _hasInternet; set { _hasInternet = value; OnPropertyChanged(); } }
        public decimal MonthlyIncome { get => _monthlyIncome; set { _monthlyIncome = value; OnPropertyChanged(); } }
        public int EnumeratorId { get => _enumeratorId; set { _enumeratorId = value; OnPropertyChanged(); } }
        public string EnumeratorName { get => _enumeratorName; set { _enumeratorName = value; OnPropertyChanged(); } }
        public DateTime SurveyDate { get => _surveyDate; set { _surveyDate = value; OnPropertyChanged(); } }
        public string Status { get => _status; set { _status = value; OnPropertyChanged(); } }
        public int MemberCount { get => _memberCount; set { _memberCount = value; OnPropertyChanged(); } }
    }

    public class Person : BaseModel
    {
        private int _personId; private int _householdId;
        private string _householdCode = string.Empty;
        private string _firstName = string.Empty; private string _lastName = string.Empty;
        private string _cnicNumber = string.Empty; private string _gender = string.Empty;
        private DateTime _dateOfBirth; private int _age;
        private string _maritalStatus = string.Empty; private string _relationship = string.Empty;
        private string _education = string.Empty; private string _occupation = string.Empty;
        private string _disability = string.Empty; private string _nationality = string.Empty;
        private string _religion = string.Empty; private string _motherTongue = string.Empty;

        public int PersonId { get => _personId; set { _personId = value; OnPropertyChanged(); } }
        public int HouseholdId { get => _householdId; set { _householdId = value; OnPropertyChanged(); } }
        public string HouseholdCode { get => _householdCode; set { _householdCode = value; OnPropertyChanged(); } }
        public string FirstName { get => _firstName; set { _firstName = value; OnPropertyChanged(); } }
        public string LastName { get => _lastName; set { _lastName = value; OnPropertyChanged(); } }
        public string FullName => $"{FirstName} {LastName}";
        public string CNICNumber { get => _cnicNumber; set { _cnicNumber = value; OnPropertyChanged(); } }
        public string Gender { get => _gender; set { _gender = value; OnPropertyChanged(); } }
        public DateTime DateOfBirth { get => _dateOfBirth; set { _dateOfBirth = value; OnPropertyChanged(); } }
        public int Age { get => _age; set { _age = value; OnPropertyChanged(); } }
        public string MaritalStatus { get => _maritalStatus; set { _maritalStatus = value; OnPropertyChanged(); } }
        public string Relationship { get => _relationship; set { _relationship = value; OnPropertyChanged(); } }
        public string Education { get => _education; set { _education = value; OnPropertyChanged(); } }
        public string Occupation { get => _occupation; set { _occupation = value; OnPropertyChanged(); } }
        public string Disability { get => _disability; set { _disability = value; OnPropertyChanged(); } }
        public string Nationality { get => _nationality; set { _nationality = value; OnPropertyChanged(); } }
        public string Religion { get => _religion; set { _religion = value; OnPropertyChanged(); } }
        public string MotherTongue { get => _motherTongue; set { _motherTongue = value; OnPropertyChanged(); } }
    }

    public class DashboardStats
    {
        public int TotalHouseholds { get; set; }
        public int TotalPersons { get; set; }
        public int TotalMales { get; set; }
        public int TotalFemales { get; set; }
        public int TotalDistricts { get; set; }
        public int TotalUCs { get; set; }
        public int SurveysThisMonth { get; set; }
        public int PendingSurveys { get; set; }
        public double LiteracyRate { get; set; }
    }
}
