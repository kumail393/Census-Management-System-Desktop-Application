using AP_Project.Models;
using AP_Project.Services;
using System.Windows;
using System.Windows.Controls;

namespace AP_Project.Views;

public partial class HouseholdFormWindow : MahApps.Metro.Controls.MetroWindow
{
    private readonly int _householdId;
    private readonly bool _isEdit;

    public HouseholdFormWindow(int householdId = 0)
    {
        InitializeComponent();
        _householdId = householdId;
        _isEdit = householdId > 0;

        LoadDropdowns();

        if (_isEdit)
        {
            txtFormTitle.Text = "Edit Household";
            var h = HouseholdService.GetById(householdId);
            if (h != null) PopulateForm(h);
        }
        else
        {
            dtpSurveyDate.SelectedDateTime = DateTime.Today;
        }
    }

    private void LoadDropdowns()
    {
        cmbProvince.ItemsSource = LocationService.GetProvinces();
        cmbEnumerator.ItemsSource = UserService.GetEnumerators();
        if (AuthService.CurrentUser?.Role == "Enumerator")
        {
            cmbEnumerator.SelectedValue = AuthService.CurrentUser.UserId;
        }
    }

    private void CmbProvince_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (cmbProvince.SelectedValue is int provId)
        {
            cmbDistrict.ItemsSource = LocationService.GetDistricts(provId);
            cmbUC.ItemsSource = null;
            txtCode.Text = "";
        }
    }

    private void CmbDistrict_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (cmbDistrict.SelectedValue is int distId)
        {
            cmbUC.ItemsSource = LocationService.GetUnionCouncils(distId);
            txtCode.Text = "";
        }
    }

    private void CmbUC_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (cmbUC.SelectedValue is int ucId && !_isEdit)
            txtCode.Text = HouseholdService.GenerateCode(ucId);
    }

    private void PopulateForm(Household h)
    {
        txtCode.Text = h.HouseholdCode;
        txtAddress.Text = h.Address;
        txtHead.Text = h.HeadOfHousehold;
        txtContact.Text = h.ContactNumber;
        dtpSurveyDate.SelectedDateTime = h.SurveyDate;
        nudRooms.Value = h.NumRooms;
        nudIncome.Value = (double)h.MonthlyIncome;
        chkSanitation.IsChecked = h.HasSanitation;
        chkInternet.IsChecked = h.HasInternet;

        SetComboByContent(cmbHousingType, h.HousingType);
        SetComboByContent(cmbOwnership, h.OwnershipStatus);
        SetComboByContent(cmbWater, h.WaterSource);
        SetComboByContent(cmbElectricity, h.ElectricitySource);
        SetComboByContent(cmbStatus, h.Status);

        // Cascade: Province -> District -> UC
        var uc = LocationService.GetUnionCouncils().FirstOrDefault(u => u.UnionCouncilId == h.UnionCouncilId);
        if (uc != null)
        {
            var district = LocationService.GetDistricts().FirstOrDefault(d => d.DistrictId == uc.DistrictId);
            if (district != null)
            {
                cmbProvince.SelectedValue = district.ProvinceId;
                cmbDistrict.ItemsSource = LocationService.GetDistricts(district.ProvinceId);
                cmbDistrict.SelectedValue = district.DistrictId;
                cmbUC.ItemsSource = LocationService.GetUnionCouncils(district.DistrictId);
                cmbUC.SelectedValue = h.UnionCouncilId;
            }
        }

        if (h.EnumeratorId > 0)
            cmbEnumerator.SelectedValue = h.EnumeratorId;
    }

    private void SetComboByContent(ComboBox combo, string value)
    {
        foreach (ComboBoxItem item in combo.Items)
        {
            if (item.Content?.ToString() == value)
            {
                combo.SelectedItem = item;
                return;
            }
        }
    }

    private void BtnSave_Click(object sender, RoutedEventArgs e)
    {
        if (!Validate()) return;

        try
        {
            var h = new Household
            {
                HouseholdId = _householdId,
                HouseholdCode = txtCode.Text,
                UnionCouncilId = (int)(cmbUC.SelectedValue ?? 0),
                Address = txtAddress.Text.Trim(),
                HeadOfHousehold = txtHead.Text.Trim(),
                ContactNumber = txtContact.Text.Trim(),
                HousingType = (cmbHousingType.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "",
                NumRooms = (int)(nudRooms.Value ?? 1),
                OwnershipStatus = (cmbOwnership.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "",
                WaterSource = (cmbWater.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "",
                ElectricitySource = (cmbElectricity.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "",
                HasSanitation = chkSanitation.IsChecked == true,
                HasInternet = chkInternet.IsChecked == true,
                MonthlyIncome = (decimal)(nudIncome.Value ?? 0),
                EnumeratorId = cmbEnumerator.SelectedValue is int eid ? eid : 0,
                SurveyDate = dtpSurveyDate.SelectedDateTime ?? DateTime.Today,
                Status = (cmbStatus.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Pending"
            };

            if (_isEdit) HouseholdService.Update(h);
            else HouseholdService.Add(h);

            DialogResult = true;
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error saving: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private bool Validate()
    {
        if (cmbUC.SelectedValue == null) { Show("Please select Union Council."); return false; }
        if (string.IsNullOrWhiteSpace(txtAddress.Text)) { Show("Address is required."); return false; }
        if (string.IsNullOrWhiteSpace(txtHead.Text)) { Show("Head of household is required."); return false; }
        if (dtpSurveyDate.SelectedDateTime == null) { Show("Survey date is required."); return false; }
        if (cmbEnumerator.SelectedValue == null) { Show("Please select enumerator."); return false; }
        return true;
    }

    private void Show(string msg) => MessageBox.Show(msg, "Validation", MessageBoxButton.OK, MessageBoxImage.Warning);
    private void BtnCancel_Click(object sender, RoutedEventArgs e) { DialogResult = false; Close(); }
}
