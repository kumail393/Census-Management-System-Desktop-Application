using AP_Project.Helpers;
using AP_Project.Services;
using System.Windows;

namespace AP_Project.Views
{
    public partial class LoginWindow : MahApps.Metro.Controls.MetroWindow
    {
        public LoginWindow()
        {
            InitializeComponent();
            // *** CHANGE THIS TO YOUR SQL SERVER NAME ***
            // Examples: "localhost\\SQLEXPRESS"  ".\SQLEXPRESS"  "localhost"
            var connStr = "Server=localhost;Database=CensusDB;Trusted_Connection=True;TrustServerCertificate=True;";
            DatabaseHelper.Initialize(connStr);
            txtUsername.Focus();
            KeyDown += (s, e) => { if (e.Key == System.Windows.Input.Key.Enter) DoLogin(); };
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e) => DoLogin();

        private void DoLogin()
        {
            txtError.Visibility = Visibility.Collapsed;
            if (string.IsNullOrWhiteSpace(txtUsername.Text) || string.IsNullOrWhiteSpace(txtPassword.Password))
            { ShowError("Please enter username and password."); return; }
            btnLogin.IsEnabled = false; btnLogin.Content = "Signing in...";
            try
            {
                if (AuthService.Login(txtUsername.Text.Trim(), txtPassword.Password))
                { new ShellWindow().Show(); Close(); }
                else ShowError("Invalid username or password.");
            }
            catch (Exception ex) { ShowError($"Connection error: {ex.Message}\n\nCheck your SQL Server connection string in LoginWindow.xaml.cs"); }
            finally { btnLogin.IsEnabled = true; btnLogin.Content = "SIGN IN"; }
        }

        private void ShowError(string msg) { txtError.Text = msg; txtError.Visibility = Visibility.Visible; }
    }
}
