using AP_Project.Helpers;
using AP_Project.Services;
using System.Windows;
using System.Windows.Controls;

namespace AP_Project.Views;

public partial class SettingsPage : Page
{
    public SettingsPage()
    {
        InitializeComponent();
        Loaded += (s, e) =>
        {
            txtLoggedUser.Text = $"{AuthService.CurrentUser?.FullName} ({AuthService.CurrentUser?.Role})";
            txtServer.Text = "localhost";
            txtDatabase.Text = "CensusDB";
        };
    }

    private void ChkWindowsAuth_Changed(object sender, RoutedEventArgs e)
    {
        if (sqlAuthPanel == null) return;
        sqlAuthPanel.Visibility = chkWindowsAuth.IsChecked == true ? Visibility.Collapsed : Visibility.Visible;
    }

    private string BuildConnectionString()
    {
        var server = txtServer.Text.Trim();
        var db = txtDatabase.Text.Trim();
        if (chkWindowsAuth.IsChecked == true)
            return $"Server={server};Database={db};Trusted_Connection=True;TrustServerCertificate=True;";
        else
            return $"Server={server};Database={db};User Id={txtSqlUser.Text};Password={pwdSqlPass.Password};TrustServerCertificate=True;";
    }

    private void BtnTestConn_Click(object sender, RoutedEventArgs e)
    {
        var cs = BuildConnectionString();
        if (DatabaseHelper.TestConnection(cs))
        {
            txtConnStatus.Text = "✓ Connection Successful";
            txtConnStatus.Foreground = System.Windows.Media.Brushes.Green;
        }
        else
        {
            txtConnStatus.Text = "✗ Connection Failed";
            txtConnStatus.Foreground = System.Windows.Media.Brushes.Red;
        }
    }

    private void BtnSaveConn_Click(object sender, RoutedEventArgs e)
    {
        var cs = BuildConnectionString();
        if (!DatabaseHelper.TestConnection(cs))
        {
            MessageBox.Show("Cannot save — connection test failed.", "Connection Error",
                MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        DatabaseHelper.Initialize(cs);
        MessageBox.Show("Connection settings saved for this session.", "Saved",
            MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void BtnChangePassword_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(pwdCurrent.Password)) { Warn("Enter current password."); return; }
        if (string.IsNullOrWhiteSpace(pwdNew.Password)) { Warn("Enter new password."); return; }
        if (pwdNew.Password != pwdNewConfirm.Password) { Warn("Passwords do not match."); return; }
        if (pwdNew.Password.Length < 6) { Warn("Password must be at least 6 characters."); return; }

        // Verify current password
        var hash = AuthService.HashPassword(pwdCurrent.Password);
        var check = DatabaseHelper.ExecuteScalar(
            "SELECT COUNT(*) FROM Users WHERE UserId=@Id AND PasswordHash=@Hash",
            new Microsoft.Data.SqlClient.SqlParameter("@Id", AuthService.CurrentUser!.UserId),
            new Microsoft.Data.SqlClient.SqlParameter("@Hash", hash));

        if (Convert.ToInt32(check) == 0) { Warn("Current password is incorrect."); return; }

        UserService.ChangePassword(AuthService.CurrentUser!.UserId, pwdNew.Password);
        pwdCurrent.Clear(); pwdNew.Clear(); pwdNewConfirm.Clear();
        MessageBox.Show("Password changed successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void Warn(string msg) => MessageBox.Show(msg, "Validation", MessageBoxButton.OK, MessageBoxImage.Warning);
}
