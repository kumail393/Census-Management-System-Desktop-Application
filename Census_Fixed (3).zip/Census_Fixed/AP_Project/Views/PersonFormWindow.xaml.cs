using AP_Project.Models;
using AP_Project.Services;
using System.Windows;
using System.Windows.Controls;

namespace AP_Project.Views;

public partial class PersonFormWindow : MahApps.Metro.Controls.MetroWindow
{
    private readonly int _householdId;
    private readonly int _personId;
    private readonly bool _isEdit;

    public PersonFormWindow(int householdId, int personId = 0)
    {
        InitializeComponent();
        _householdId = householdId;
        _personId = personId;
        _isEdit = personId > 0;

        if (_isEdit)
        {
            txtTitle.Text = "Edit Person";
            var p = PersonService.GetById(personId);
            if (p != null) PopulateForm(p);
        }
        else
        {
            dtpDOB.SelectedDateTime = DateTime.Today.AddYears(-25);
            SetComboByContent(cmbRelation, "Head");
            SetComboByContent(cmbMarital, "Single");
            SetComboByContent(cmbGender, "Male");
            SetComboByContent(cmbEducation, "None");
            SetComboByContent(cmbOccupation, "Unemployed");
            SetComboByContent(cmbDisability, "None");
            SetComboByContent(cmbReligion, "Islam");
            SetComboByContent(cmbNationality, "Pakistani");
            SetComboByContent(cmbMotherTongue, "Urdu");
        }
    }

    private void PopulateForm(Person p)
    {
        txtFirst.Text = p.FirstName;
        txtLast.Text = p.LastName;
        txtCNIC.Text = p.CNICNumber;
        dtpDOB.SelectedDateTime = p.DateOfBirth;
        txtAge.Text = p.Age.ToString();
        SetComboByContent(cmbGender, p.Gender);
        SetComboByContent(cmbMarital, p.MaritalStatus);
        SetComboByContent(cmbRelation, p.Relationship);
        SetComboByContent(cmbEducation, p.Education);
        SetComboByContent(cmbOccupation, p.Occupation);
        SetComboByContent(cmbDisability, p.Disability);
        SetComboByContent(cmbReligion, p.Religion);
        SetComboByContent(cmbNationality, p.Nationality);
        SetComboByContent(cmbMotherTongue, p.MotherTongue);
    }

    private void SetComboByContent(ComboBox combo, string value)
    {
        foreach (ComboBoxItem item in combo.Items)
            if (item.Content?.ToString() == value) { combo.SelectedItem = item; return; }
    }

    private void DtpDOB_Changed(object sender, EventArgs e)
    {
        if (dtpDOB.SelectedDateTime.HasValue)
            txtAge.Text = PersonService.CalculateAge(dtpDOB.SelectedDateTime.Value).ToString();
    }

    private void BtnSave_Click(object sender, RoutedEventArgs e)
    {
        if (!Validate()) return;
        try
        {
            var p = new Person
            {
                PersonId = _personId,
                HouseholdId = _householdId,
                FirstName = txtFirst.Text.Trim(),
                LastName = txtLast.Text.Trim(),
                CNICNumber = txtCNIC.Text.Trim(),
                Gender = (cmbGender.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "",
                DateOfBirth = dtpDOB.SelectedDateTime ?? DateTime.Today.AddYears(-25),
                MaritalStatus = (cmbMarital.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "",
                Relationship = (cmbRelation.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "",
                Education = (cmbEducation.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "",
                Occupation = (cmbOccupation.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "",
                Disability = (cmbDisability.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "None",
                Religion = (cmbReligion.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "",
                Nationality = (cmbNationality.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "",
                MotherTongue = (cmbMotherTongue.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? ""
            };

            if (_isEdit) PersonService.Update(p);
            else PersonService.Add(p);

            DialogResult = true;
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error saving: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private bool Validate()
    {
        if (string.IsNullOrWhiteSpace(txtFirst.Text)) { Warn("First name is required."); return false; }
        if (string.IsNullOrWhiteSpace(txtLast.Text)) { Warn("Last name is required."); return false; }
        if (cmbGender.SelectedItem == null) { Warn("Gender is required."); return false; }
        if (dtpDOB.SelectedDateTime == null) { Warn("Date of birth is required."); return false; }
        return true;
    }

    private void Warn(string msg) => MessageBox.Show(msg, "Validation", MessageBoxButton.OK, MessageBoxImage.Warning);
    private void BtnCancel_Click(object sender, RoutedEventArgs e) { DialogResult = false; Close(); }
}
