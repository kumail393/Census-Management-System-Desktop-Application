using AP_Project.Services;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace AP_Project.Views
{
    public partial class ShellWindow : MahApps.Metro.Controls.MetroWindow
    {
        private Button? _activeBtn;
        private readonly DispatcherTimer _clock = new() { Interval = TimeSpan.FromSeconds(1) };

        public ShellWindow()
        {
            InitializeComponent();
            var u = AuthService.CurrentUser;
            if (u != null)
            {
                txtUserName.Text = u.FullName;
                txtUserRole.Text = u.Role;
                if (u.Role != "Admin")
                {
                    btnUsers.Visibility    = Visibility.Collapsed;
                    adminLabel.Visibility  = Visibility.Collapsed;
                }
            }
            _clock.Tick += (s, e) => txtClock.Text = DateTime.Now.ToString("ddd  dd-MMM-yyyy   HH:mm:ss");
            _clock.Start();
            txtClock.Text = DateTime.Now.ToString("ddd  dd-MMM-yyyy   HH:mm:ss");
            Navigate("Dashboard", btnDashboard);
        }

        // ── Navigation ───────────────────────────────────────────────
        private void Nav_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button b) Navigate(b.Tag?.ToString() ?? "Dashboard", b);
        }

        private void Navigate(string page, Button? btn)
        {
            if (_activeBtn != null) _activeBtn.Style = (Style)FindResource("NavButtonStyle");
            if (btn != null) { btn.Style = (Style)FindResource("NavButtonActiveStyle"); _activeBtn = btn; }

            txtPageTitle.Text = page switch
            {
                "Dashboard"  => "Dashboard",
                "Households" => "Households Management",
                "Persons"    => "Persons / Population",
                "Locations"  => "Locations Management",
                "Reports"    => "Reports & Analytics",
                "Users"      => "User Management",
                "Settings"   => "System Settings",
                _            => page
            };

            System.Windows.Controls.Page? p = page switch
            {
                "Dashboard"  => new DashboardPage(),
                "Households" => new HouseholdsPage(),
                "Persons"    => new PersonsPage(),
                "Locations"  => new LocationsPage(),
                "Reports"    => new ReportsPage(),
                "Users"      => new UsersPage(),
                "Settings"   => new SettingsPage(),
                _            => new DashboardPage()
            };
            ContentFrame.Navigate(p);
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to logout?", "Logout",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                _clock.Stop();
                AuthService.Logout();
                new LoginWindow().Show();
                Close();
            }
        }
    }
}
