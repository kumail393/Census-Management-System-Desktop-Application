using AP_Project.Models;
using AP_Project.Services;
using System.Linq;
using System.Windows;

namespace AP_Project.Views;

public partial class HouseholdMembersWindow : MahApps.Metro.Controls.MetroWindow
{
    private readonly Household _household;

    public HouseholdMembersWindow(Household household)
    {
        InitializeComponent();
        _household = household;
        txtHouseholdHeader.Text = $"{household.HouseholdCode}  —  {household.HeadOfHousehold}";
        txtHouseholdAddress.Text = household.Address;
        txtUCName.Text = household.UCName;
        txtIncome.Text = $"PKR {household.MonthlyIncome:N0}";
        LoadMembers();
    }

    private void LoadMembers()
    {
        var members = PersonService.GetByHousehold(_household.HouseholdId);
        dgMembers.ItemsSource = members;
        txtMemberCount.Text = $"{members.Count} Members";

        // Stats
        int males   = members.Count(p => p.Gender == "Male");
        int females = members.Count(p => p.Gender == "Female");
        double avg  = members.Count > 0 ? members.Average(p => p.Age) : 0;

        txtMaleCount.Text   = males.ToString();
        txtFemaleCount.Text = females.ToString();
        txtAvgAge.Text      = avg.ToString("F0");
    }

    private void BtnAddMember_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new PersonFormWindow(_household.HouseholdId);
        if (dlg.ShowDialog() == true) LoadMembers();
    }

    private void BtnEditMember_Click(object sender, RoutedEventArgs e)
    {
        if (dgMembers.SelectedItem is Person p)
        {
            var dlg = new PersonFormWindow(_household.HouseholdId, p.PersonId);
            if (dlg.ShowDialog() == true) LoadMembers();
        }
        else MessageBox.Show("Select a member to edit.", "Select Member",
                             MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void BtnRemoveMember_Click(object sender, RoutedEventArgs e)
    {
        if (dgMembers.SelectedItem is Person p)
        {
            var r = MessageBox.Show($"Delete member '{p.FullName}'?", "Confirm Delete",
                        MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (r == MessageBoxResult.Yes)
            {
                PersonService.Delete(p.PersonId);
                LoadMembers();
            }
        }
        else MessageBox.Show("Select a member to remove.", "Select Member",
                             MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void BtnClose_Click(object sender, RoutedEventArgs e) => Close();
}
