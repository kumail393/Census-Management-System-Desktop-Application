using AP_Project.Models;
using AP_Project.Services;
using System.Windows;
using System.Windows.Controls;

namespace AP_Project.Views;

public partial class HouseholdsPage : Page
{
    private List<Household> _households = [];

    public HouseholdsPage()
    {
        InitializeComponent();
        Loaded += (s, e) => LoadData();
    }

    private void LoadData()
    {
        try
        {
            var search = txtSearch.Text.Trim();
            var status = (cmbStatusFilter.SelectedItem as ComboBoxItem)?.Content?.ToString();
            if (status == "All Status") status = null;

            _households = HouseholdService.GetAll(search: search, status: status);
            dgHouseholds.ItemsSource = _households;
            txtStatus.Text = $"Total: {_households.Count} households";
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void BtnAdd_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new HouseholdFormWindow();
        if (dlg.ShowDialog() == true) LoadData();
    }

    private void BtnEdit_Click(object sender, RoutedEventArgs e)
    {
        if (dgHouseholds.SelectedItem is Household h)
        {
            var dlg = new HouseholdFormWindow(h.HouseholdId);
            if (dlg.ShowDialog() == true) LoadData();
        }
        else MessageBox.Show("Please select a household to edit.", "Select Household",
            MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void BtnDelete_Click(object sender, RoutedEventArgs e)
    {
        if (dgHouseholds.SelectedItem is Household h)
        {
            var r = MessageBox.Show($"Delete household '{h.HouseholdCode}' and all its members?\nThis cannot be undone.",
                "Confirm Delete", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (r == MessageBoxResult.Yes)
            {
                HouseholdService.Delete(h.HouseholdId);
                LoadData();
            }
        }
        else MessageBox.Show("Please select a household to delete.", "Select Household",
            MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void BtnViewMembers_Click(object sender, RoutedEventArgs e)
    {
        if (dgHouseholds.SelectedItem is Household h)
        {
            var dlg = new HouseholdMembersWindow(h);
            dlg.ShowDialog();
            LoadData();
        }
        else MessageBox.Show("Please select a household.", "Select Household",
            MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void BtnRefresh_Click(object sender, RoutedEventArgs e) => LoadData();
    private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e) { if (IsLoaded) LoadData(); }
    private void Filter_Changed(object sender, SelectionChangedEventArgs e) { if (IsLoaded) LoadData(); }
    private void DgHouseholds_SelectionChanged(object sender, SelectionChangedEventArgs e) { }
}
