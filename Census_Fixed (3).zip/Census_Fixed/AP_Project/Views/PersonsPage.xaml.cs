using AP_Project.Services;
using System.Windows.Controls;

namespace AP_Project.Views;

public partial class PersonsPage : Page
{
    public PersonsPage()
    {
        InitializeComponent();
        Loaded += (s, e) =>
        {
            var districts = LocationService.GetDistricts();
            districts.Insert(0, new Models.District { DistrictId = 0, DistrictName = "All Districts" });
            cmbDistrictFilter.ItemsSource = districts;
            cmbDistrictFilter.SelectedIndex = 0;
            LoadData();
        };
    }

    private void LoadData()
    {
        var search = txtSearch.Text.Trim();
        var gender = (cmbGenderFilter.SelectedItem as ComboBoxItem)?.Content?.ToString();
        if (gender == "All Gender") gender = null;
        var districtId = cmbDistrictFilter.SelectedValue is int dv && dv != 0 ? (int?)dv : null;

        var persons = PersonService.GetAll(search, gender, districtId);
        dgPersons.ItemsSource = persons;
        txtCount.Text = $"Total: {persons.Count:N0} persons";
    }

    private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e) { if (IsLoaded) LoadData(); }
    private void Filter_Changed(object sender, SelectionChangedEventArgs e) { if (IsLoaded) LoadData(); }
    private void BtnRefresh_Click(object sender, System.Windows.RoutedEventArgs e) => LoadData();
}
