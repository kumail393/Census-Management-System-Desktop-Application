using AP_Project.Services;
using System.Windows.Controls;

namespace AP_Project.Views;

public partial class DashboardPage : Page
{
    public DashboardPage()
    {
        InitializeComponent();
        Loaded += (s, e) => LoadData();
    }

    private void LoadData()
    {
        try
        {
            var stats = DashboardService.GetStats();
            txtTotalHouseholds.Text = stats.TotalHouseholds.ToString("N0");
            txtTotalPopulation.Text = stats.TotalPersons.ToString("N0");
            txtMales.Text = stats.TotalMales.ToString("N0");
            txtFemales.Text = stats.TotalFemales.ToString("N0");
            txtDistricts.Text = stats.TotalDistricts.ToString();
            txtThisMonth.Text = stats.SurveysThisMonth.ToString();
            txtPending.Text = stats.PendingSurveys.ToString();
            txtLiteracyRate.Text = $"{stats.LiteracyRate}%";

            var recent = DashboardService.GetRecentActivity();
            if (recent != null) dgRecent.ItemsSource = recent.DefaultView;
        }
        catch (Exception ex)
        {
            System.Windows.MessageBox.Show($"Error loading dashboard: {ex.Message}", "Error",
                System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning);
        }
    }

    private void BtnRefresh_Click(object sender, System.Windows.RoutedEventArgs e) => LoadData();
}
