using System.Linq;
using AP_Project.Models;
using AP_Project.Services;
using System.Windows;
using System.Windows.Controls;

namespace AP_Project.Views;

public partial class UsersPage : Page
{
    private int _editingUserId = 0;

    public UsersPage()
    {
        InitializeComponent();
        Loaded += (s, e) => LoadUsers();
    }

    private void LoadUsers()
    {
        var search = txtSearch?.Text?.Trim() ?? "";
        var all = UserService.GetAll();
        var filtered = string.IsNullOrEmpty(search)
            ? all
            : all.Where(u => u.Username.Contains(search, StringComparison.OrdinalIgnoreCase)
                          || u.FullName.Contains(search, StringComparison.OrdinalIgnoreCase)
                          || u.Email.Contains(search, StringComparison.OrdinalIgnoreCase)).ToList();
        dgUsers.ItemsSource = filtered;
        if (txtUserCount != null) txtUserCount.Text = $"{filtered.Count} users";
    }

    private void TxtSearch_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
    {
        if (IsLoaded) LoadUsers();
    }

    private void DgUsers_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!IsLoaded) return;
        if (dgUsers.SelectedItem is User u)
        {
            _editingUserId = u.UserId;
            txtFormTitle.Text = "Edit User";
            txtUsername.Text = u.Username;
            txtFullName.Text = u.FullName;
            txtEmail.Text = u.Email;
            SetCombo(cmbRole, u.Role);
            chkIsActive.IsChecked = u.IsActive;
            pwdPassword.Clear();
            pwdConfirm.Clear();
        }
    }

    private void SetCombo(ComboBox cb, string val)
    {
        foreach (ComboBoxItem item in cb.Items)
            if (item.Content?.ToString() == val) { cb.SelectedItem = item; return; }
    }

    private void BtnNew_Click(object sender, RoutedEventArgs e) => BtnClear_Click(sender, e);

    private void BtnSave_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtUsername.Text)) { Warn("Username required."); return; }
        if (string.IsNullOrWhiteSpace(txtFullName.Text)) { Warn("Full name required."); return; }

        bool isEdit = _editingUserId > 0;

        if (!isEdit && string.IsNullOrWhiteSpace(pwdPassword.Password))
        { Warn("Password required for new user."); return; }
        if (!string.IsNullOrWhiteSpace(pwdPassword.Password) && pwdPassword.Password != pwdConfirm.Password)
        { Warn("Passwords do not match."); return; }
        if (UserService.UsernameExists(txtUsername.Text.Trim(), _editingUserId))
        { Warn("Username already exists."); return; }

        try
        {
            var u = new User
            {
                UserId = _editingUserId,
                Username = txtUsername.Text.Trim(),
                FullName = txtFullName.Text.Trim(),
                Email = txtEmail.Text.Trim(),
                Role = (cmbRole.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Viewer",
                IsActive = chkIsActive.IsChecked == true
            };

            if (isEdit)
            {
                UserService.Update(u);
                if (!string.IsNullOrWhiteSpace(pwdPassword.Password))
                    UserService.ChangePassword(_editingUserId, pwdPassword.Password);
            }
            else
            {
                UserService.Add(u, pwdPassword.Password);
            }

            MessageBox.Show("User saved successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            BtnClear_Click(sender, e);
            LoadUsers();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void BtnDelete_Click(object sender, RoutedEventArgs e)
    {
        if (_editingUserId == 0) { Warn("Select a user first."); return; }
        if (_editingUserId == AuthService.CurrentUser?.UserId) { Warn("Cannot delete your own account."); return; }

        var r = MessageBox.Show("Delete this user?", "Confirm Delete", MessageBoxButton.YesNo, MessageBoxImage.Warning);
        if (r == MessageBoxResult.Yes)
        {
            UserService.Delete(_editingUserId);
            BtnClear_Click(sender, e);
            LoadUsers();
        }
    }

    private void BtnClear_Click(object sender, RoutedEventArgs e)
    {
        _editingUserId = 0;
        txtFormTitle.Text = "Add New User";
        txtUsername.Clear(); txtFullName.Clear(); txtEmail.Clear();
        pwdPassword.Clear(); pwdConfirm.Clear();
        cmbRole.SelectedIndex = 1;
        chkIsActive.IsChecked = true;
        dgUsers.SelectedItem = null;
    }

    private void BtnRefresh_Click(object sender, RoutedEventArgs e) => LoadUsers();
    private void Warn(string msg) => MessageBox.Show(msg, "Validation", MessageBoxButton.OK, MessageBoxImage.Warning);
}
