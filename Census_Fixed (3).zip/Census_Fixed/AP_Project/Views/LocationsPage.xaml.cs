using AP_Project.Models;
using AP_Project.Services;
using System.Windows;
using System.Windows.Controls;

namespace AP_Project.Views;

public partial class LocationsPage : Page
{
    public LocationsPage()
    {
        InitializeComponent();
        Loaded += (s, e) => LoadAll();
    }

    private void LoadAll()
    {
        var provinces = LocationService.GetProvinces();
        lstProvinces.ItemsSource = provinces;
        cmbProvinceForDistrict.ItemsSource = provinces;
        txtProvinceCount.Text = $"{provinces.Count} provinces";

        var districts = LocationService.GetDistricts();
        lstDistricts.ItemsSource = districts;
        cmbDistrictForUC.ItemsSource = districts;
        txtDistrictCount.Text = $"{districts.Count} districts";

        var ucs = LocationService.GetUnionCouncils();
        lstUCs.ItemsSource = ucs;
        txtUCCount.Text = $"{ucs.Count} union councils";
    }

    private void LstProvinces_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!IsLoaded) return;
        if (lstProvinces.SelectedItem is Province p)
        {
            var districts = LocationService.GetDistricts(p.ProvinceId);
            lstDistricts.ItemsSource = districts;
            txtDistrictCount.Text = $"{districts.Count} districts";
            lstUCs.ItemsSource = null;
            txtUCCount.Text = "";
        }
    }

    private void LstDistricts_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!IsLoaded) return;
        if (lstDistricts.SelectedItem is District d)
        {
            var ucs = LocationService.GetUnionCouncils(d.DistrictId);
            lstUCs.ItemsSource = ucs;
            txtUCCount.Text = $"{ucs.Count} union councils";
        }
    }

    private void BtnAddProvince_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtProvinceName.Text)) { Warn("Enter province name."); return; }
        LocationService.AddProvince(new Province
        {
            ProvinceName = txtProvinceName.Text.Trim(),
            ProvinceCode = txtProvinceCode.Text.Trim()
        });
        txtProvinceName.Clear(); txtProvinceCode.Clear();
        LoadAll();
    }

    private void BtnAddDistrict_Click(object sender, RoutedEventArgs e)
    {
        if (cmbProvinceForDistrict.SelectedValue == null) { Warn("Select a province."); return; }
        if (string.IsNullOrWhiteSpace(txtDistrictName.Text)) { Warn("Enter district name."); return; }
        LocationService.AddDistrict(new District
        {
            ProvinceId = (int)cmbProvinceForDistrict.SelectedValue,
            DistrictName = txtDistrictName.Text.Trim(),
            DistrictCode = txtDistrictCode.Text.Trim()
        });
        txtDistrictName.Clear(); txtDistrictCode.Clear();
        LoadAll();
    }

    private void BtnAddUC_Click(object sender, RoutedEventArgs e)
    {
        if (cmbDistrictForUC.SelectedValue == null) { Warn("Select a district."); return; }
        if (string.IsNullOrWhiteSpace(txtUCName.Text)) { Warn("Enter union council name."); return; }
        LocationService.AddUnionCouncil(new UnionCouncil
        {
            DistrictId = (int)cmbDistrictForUC.SelectedValue,
            UnionCouncilName = txtUCName.Text.Trim(),
            UCCode = txtUCCode.Text.Trim(),
            UCType = (cmbUCType.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Urban"
        });
        txtUCName.Clear(); txtUCCode.Clear();
        LoadAll();
    }

    private void Warn(string msg) => MessageBox.Show(msg, "Validation", MessageBoxButton.OK, MessageBoxImage.Warning);
}
